#pragma once
#include "pt_card.h"

Uint16_t ua_card_initpre(const Uint8_t *script_path, Uint8_t *user_data, Uint32_t user_data_len, Uint8_t *output_info, Uint32_t *output_info_len);
