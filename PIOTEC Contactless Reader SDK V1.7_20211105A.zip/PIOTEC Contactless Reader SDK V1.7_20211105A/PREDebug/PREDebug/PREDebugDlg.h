// PREDebugDlg.h : ͷ�ļ�
//

#pragma once


// CPREDebugDlg �Ի���
class CPREDebugDlg : public CDialog
{
// ����
public:
	CPREDebugDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_PREDEBUG_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonScriptPath();
public:
	afx_msg void OnBnClickedButtonInitpre();
public:
	afx_msg void OnBnClickedButtonRunpre();
public:
	afx_msg void OnBnClickedButtonExitpre();
public:
	afx_msg void OnBnClickedButtonClear();
};