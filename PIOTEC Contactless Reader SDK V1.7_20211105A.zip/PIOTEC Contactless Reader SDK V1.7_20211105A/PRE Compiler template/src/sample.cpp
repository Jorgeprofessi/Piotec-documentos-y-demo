#include <iostream>
#include <string.h>
#include "pt_card.h"

#ifdef __cplusplus  
extern "C"{
#endif  

using namespace std;

Uint16_t ua_card_initpre(const Uint8_t *script_path,const Uint8_t *user_data, Uint32_t user_data_len, Uint8_t *output_info, Uint32_t *output_info_len)
{
	return 0;
}

Uint16_t ua_card_runpre(Uint8_t *user_data, const Uint32_t user_data_len, Uint8_t *output_info, Uint32_t *output_info_len)
{
	card_obj_t obj;
	card_err_t ret;
	ret = card_open(&obj, MODEL_P14443A, NULL);
	printf("ua_card_runpre open = %d\n", ret);
	if (ret != 0)
		return ret;
	ret = card_close(&obj);
	/*
	memcpy(output_info, user_data, user_data_len);
	*output_info_len = user_data_len;
	*/
	return ret;
}

Uint16_t ua_card_exitpre(Uint8_t *output_info, Uint32_t *output_info_len)
{
	return 0;
}
#ifdef __cplusplus  
}  
#endif
