#include <iostream>
#include <deque>
#include <stdlib.h>
#include <string.h>
#include "pt_card.h"

#ifdef __cplusplus  
extern "C"{
#endif  

using namespace std;
#define NO_ERR	0
/* User-defined error code(More than 0x5000) */
#define USERERR_FILE_OPEN	0x5001
#define USERERR_MEMORY		0x5002
#define USERERR_PARSE		0x5003
#define USERERR_PARAM		0x5004
#define USERERR_SW			0x5005
/* User-defined buffer size */
#define USER_BUFF_SIZE	1024

typedef enum data_type {
	DTYPE_ON = 1,
	DTYPE_OFF,
	DTYPE_RESET,
	DTYPE_APDU,
	DTYPE_APDU_KEY_STR
} e_dtype_t;

typedef struct script {
	e_dtype_t type;
	Uint8_t *data;
	Uint16_t data_len;
	Uint8_t sw[2];
} script_t;

typedef deque<script_t> DQSCRIPT;
typedef deque<string> DQKEY;
typedef deque<string> DQDATA;
DQSCRIPT dq_script;
DQKEY dq_key;
DQDATA dq_data;

#ifdef WIN32
/* IP is not used for embedded run, its for debug */
extern char *debug_ip;
#endif

/* String converted to hexadecimal */
static Uint16_t strtohex(const char *src, int len, unsigned char *buf)
{
	Uint16_t i = 0;
	unsigned int hex;

	if (len % 2)
		return i;
	for (i = 0; i < len / 2; i++) {
		sscanf(src + 2 * i, "%02x", &hex);
		buf[i] = hex;
	}
	return i;
}

/* Trim string */
static char *trim(char *p)
{
	int i, j = 0;
	for (i = 0; p[i] != '\0'; i++) {
		/* 0x0D='^M' */
		if (p[i] != '\t' && p[i] != '\n' && p[i] != 0x0D)
			p[j++] = p[i];
	}
	p[j] = '\0';

	return p;
}

/* String replacement */
static void repalce_all(string& str, const string& old_value, const string& new_value)
{
	for(string::size_type pos(0); pos!= string::npos; pos += new_value.length()) {
		if ((pos = str.find(old_value,pos)) != string::npos)
			str.replace(pos, old_value.length(), new_value);
		else
			break;
	}
	return;
}

Uint16_t ua_card_initpre(const Uint8_t *script_path,const Uint8_t *user_data,const Uint32_t user_data_len, Uint8_t *output_info, Uint32_t *output_info_len)
{
#if 1
	FILE *fp;
	char line[2 * USER_BUFF_SIZE];
	script_t st_script;
	char *sw_pos = NULL;
	char *key_token = NULL;
	char key_tmp[USER_BUFF_SIZE];
	string key_str = "";
	string str_begin = "<";
	string str_end = ">";
	Uint8_t apdu[USER_BUFF_SIZE];
	Uint16_t apdu_len = 0;
	Uint8_t sw[2];
	Uint16_t ret = NO_ERR;
	int i = 0;
	int flag = 0;

	dq_key.clear();
	dq_script.clear();
	/* Add key to key deque from user_data(Key separator for ',') */
	if (user_data) {
		memset(key_tmp, 0, sizeof(key_tmp));
		memcpy(key_tmp, (char *)user_data, user_data_len);
		key_token = strtok(key_tmp, ",");
		while (key_token != NULL) {
			key_str = "";
			key_str.append(str_begin);
			key_str.append(key_token);
			key_str.append(str_end);
			dq_data.push_back(key_str);
			key_token = strtok(NULL, ",");
		}
	}
	if (script_path == NULL) {
		if (output_info) {
			sprintf((char *)output_info, "%s", "Script file path is NULL");
			*output_info_len = (Uint32_t)strlen((char *)output_info);
		}
		return USERERR_FILE_OPEN;
	}
	/* Read the script stored in script deque */
	fp = fopen((const char *)script_path, "r");
	if (fp == NULL) {
		if (output_info) {
			sprintf((char *)output_info, "%s", "Open script file error");
			*output_info_len = (Uint32_t)strlen((char *)output_info);
		}
		return USERERR_FILE_OPEN;
	}
	memset(line, 0, sizeof(line));
	while (fgets(line, sizeof(line) - 1, fp) != NULL) {
		if (strlen(line) == 0 || line[0] == '/' || line[0] == '\n' || line[0] == '\t')
			continue;
		memset(&st_script, 0, sizeof(script_t));
		trim(line);
		if (strstr(line, "ON")) {
			st_script.type = DTYPE_ON;
			st_script.data = NULL;
			st_script.data_len = 0;
			dq_script.push_back(st_script);
			continue;
		} else if (strstr(line, "OFF")) {
			st_script.type = DTYPE_OFF;
			st_script.data = NULL;
			st_script.data_len = 0;
			dq_script.push_back(st_script);
			continue;
		} else if (strstr(line, "RESET") || strstr(line, "Reset")) {
			st_script.type = DTYPE_RESET;
			st_script.data = NULL;
			st_script.data_len = 0;
			dq_script.push_back(st_script);
			continue;
		} else {
			/* Extract SW data */
			memset(sw, 0, sizeof(sw));
			sw_pos = strstr(line, "SW");
			if (sw_pos) {
				if (strtohex(sw_pos + 2, 4, sw) < 0) {
					if (output_info) {
						sprintf((char *)output_info, "%s", "Parse sw error");
						*output_info_len = (Uint32_t)strlen((char *)output_info);
					}
					ret = USERERR_PARSE;
					break;
				}
			}
			/* Check the key in the line */
			/* Has key */
			for (i = 0; i < (int)dq_key.size(); i++) {
				if (strstr(line, dq_key.at(i).c_str())) {
					st_script.type = DTYPE_APDU_KEY_STR;
					if (sw_pos)
						st_script.data_len = (Uint16_t)strlen(line) - (Uint16_t)strlen(sw_pos);
					else
						st_script.data_len = (Uint16_t)strlen(line);
					/* For add \0 */
					st_script.data = (Uint8_t *)malloc(st_script.data_len + 1);
					memset(st_script.data, 0, st_script.data_len + 1);
					memcpy(st_script.data, line, st_script.data_len);
					memcpy(st_script.sw, sw, 2);
					dq_script.push_back(st_script);
					flag = 1;
					break;
				}
			}
			if (flag) {
				flag = 0;
				continue;
			}
			/* No key */
			memset(apdu, 0, sizeof(apdu));
			apdu_len = strtohex(line, (int)(strlen(line) - (sw_pos ? strlen(sw_pos) : 0)), apdu);
			if (apdu_len < 0) {
				if (output_info) {
					sprintf((char *)output_info, "%s", "Parse apdu error");
					*output_info_len = (Uint32_t)strlen((char *)output_info);
				}
				ret = USERERR_PARSE;
				break;
			}
			st_script.type = DTYPE_APDU;
			st_script.data = (Uint8_t *)malloc(apdu_len);
			memcpy(st_script.data, apdu, apdu_len);
			st_script.data_len = apdu_len;
			memcpy(st_script.sw, sw, 2);
			dq_script.push_back(st_script);
			continue;
		}
	}
	fclose(fp);
	if (output_info) {
		sprintf((char *)output_info, "%s", "Init");
		*output_info_len = (Uint32_t)strlen((char *)output_info);
	}
	return ret;
#endif
	return 0;
}

Uint16_t ua_card_runpre(const Uint8_t *user_data, const Uint32_t user_data_len, Uint8_t *output_info, Uint32_t *output_info_len)
{
#if 0
	card_obj_t obj;
	card_err_t ret;
	Uint8_t apdu[USER_BUFF_SIZE];
	Uint16_t apdu_len = 0;
	Uint8_t resp[USER_BUFF_SIZE];
	Uint16_t resp_len = 0;
	string apdu_str = "";
	char *data_token = NULL;
	char *data_tmp = NULL;
	int i = 0;
	int j = 0;

	
#ifdef WIN32
	/* IP is not used for embedded run, its for debug */
	ret = card_open(&obj, MODEL_P14443A, (Uint8_t *)debug_ip);
#else
	ret = card_open(&obj, MODEL_P14443A, NULL);
#endif
	if (ret != CARD_NO_ERR) {
		if (output_info) {
			sprintf((char *)output_info, "%s", "Open reader error");
			*output_info_len = (Uint32_t)strlen((char *)output_info);
		}
		card_close(&obj);
		return ret;
	}
	dq_data.clear();
	if (user_data && user_data_len != 0) {
		/* Add data to data deque from user_data(Key separator for ',') */
		data_tmp = (char *)malloc(user_data_len);
		memcpy(data_tmp, (char *)user_data, user_data_len);
		data_token = strtok(data_tmp, ",");
		while (data_token != NULL) {
			dq_data.push_back(data_token);
			data_token = strtok(NULL, ",");
		}
	}
	for (i = 0; i < (int)dq_script.size(); i++) {
		switch (dq_script.at(i).type) {
			case DTYPE_ON:
				printf("PRE start on\n");
				ret = card_on(&obj);
				printf("PRE finish on ret = %d\n", ret);
				if (ret != CARD_NO_ERR) {
					if (output_info) {
						sprintf((char *)output_info, "%s", "Card on error");
						*output_info_len = (Uint32_t)strlen((char *)output_info);
					}
					card_close(&obj);
					return ret;
				}
				break;
			case DTYPE_OFF:
				ret = card_off(&obj);
				if (ret != CARD_NO_ERR) {
					if (output_info) {
						sprintf((char *)output_info, "%s", "Card off error");
						*output_info_len = (Uint32_t)strlen((char *)output_info);
					}
					card_close(&obj);
					return ret;
				}
				break;
			case DTYPE_RESET:
				printf("PRE RESET\n");
				ret = card_reset(&obj);
				if (ret != CARD_NO_ERR) {
					if (output_info) {
						sprintf((char *)output_info, "%s", "Card reset error");
						*output_info_len = (Uint32_t)strlen((char *)output_info);
					}
					card_off(&obj);
					card_close(&obj);
					return ret;
				}
				break;
			case DTYPE_APDU_KEY_STR:
				if (dq_data.size() == 0) {
					if (output_info) {
						sprintf((char *)output_info, "%s", "User data error");
						*output_info_len = (Uint32_t)strlen((char *)output_info);
					}
					card_off(&obj);
					card_close(&obj);
					return USERERR_PARAM;
				}
				/* Check the number of matches between key and data */
				if (dq_key.size() != dq_data.size()) {
					if (output_info) {
						sprintf((char *)output_info, "%s", "Key and data number is not match");
						*output_info_len = (Uint32_t)strlen((char *)output_info);
					}
					card_off(&obj);
					card_close(&obj);
					return USERERR_PARAM;
				}
				apdu_str = (char *)dq_script.at(i).data;
				/* Replace key */
				for (j = 0; j < (int)dq_key.size(); j++) {
					repalce_all(apdu_str, dq_key.at(j), dq_data.at(j));
				}
				memset(apdu, 0, sizeof(apdu));
				apdu_len = strtohex(apdu_str.c_str(), (int)apdu_str.length(), apdu);
				if (apdu_len < 0) {
					if (output_info) {
						sprintf((char *)output_info, "%s", "Parse apdu error");
						*output_info_len = (Uint32_t)strlen((char *)output_info);
					}
					ret = USERERR_PARSE;
					break;
				}
				ret = card_pipe(&obj, apdu, apdu_len, resp, &resp_len);
				if (ret != CARD_NO_ERR) {
					if (output_info) {
						sprintf((char *)output_info, "%s", "Card pipe error");
						*output_info_len = (Uint32_t)strlen((char *)output_info);
					}
					card_off(&obj);
					card_close(&obj);
					return ret;
				}
				if ((dq_script.at(i).sw[0] != 0x00 && dq_script.at(i).sw[1] != 0x00) &&
						(dq_script.at(i).sw[0] != obj.sw1 || dq_script.at(i).sw[1] != obj.sw2)) {
					if (output_info) {
						sprintf((char *)output_info, "%s,SW=%02x%02x", "check sw error", obj.sw1, obj.sw2);
						*output_info_len = (Uint32_t)strlen((char *)output_info);
					}
					card_off(&obj);
					card_close(&obj);
					return USERERR_SW;
				}
				break;
			case DTYPE_APDU:
				ret = card_pipe(&obj, dq_script.at(i).data, dq_script.at(i).data_len, resp, &resp_len);
				if (ret != CARD_NO_ERR) {
					if (output_info) {
						sprintf((char *)output_info, "%s", "Card pipe error");
						*output_info_len = (Uint32_t)strlen((char *)output_info);
					}
					card_off(&obj);
					card_close(&obj);
					return ret;
				}
				if (dq_script.at(i).sw[0] == 0x00 && dq_script.at(i).sw[1] == 0x00)
					break;
				if ((dq_script.at(i).sw[0] != obj.sw1 || dq_script.at(i).sw[1] != obj.sw2) && output_info) {
					sprintf((char *)output_info, "%s,SW=%02x%02x", "check sw error", obj.sw1, obj.sw2);
					*output_info_len = (Uint32_t)strlen((char *)output_info);
					card_off(&obj);
					card_close(&obj);
					return USERERR_SW;
				}
				break;
			default:
				break;
		}
	}
	card_off(&obj);
	card_close(&obj);
	if (output_info) {
		sprintf((char *)output_info, "%s", "Finish run");
		*output_info_len = (Uint32_t)strlen((char *)output_info);
	}
#endif
	return NO_ERR;
}

Uint16_t ua_card_exitpre(Uint8_t *output_info, Uint32_t *output_info_len)
{
	int i = 0;

	printf("ua_card_exitpre start\n");
	for (i = 0; i < (int)dq_script.size(); i++) {
		if (dq_script.at(i).data) {
			free(dq_script.at(i).data);
			dq_script.at(i).data = NULL;
		}
	}
	printf("ua_card_exitpre end1\n");
	dq_data.clear();
	dq_key.clear();
	dq_script.clear();
	if (output_info) {
		sprintf((char *)output_info, "%s", "Exit");
		*output_info_len = (Uint32_t)strlen((char *)output_info);
	}
	printf("ua_card_exitpre end2\n");
	return NO_ERR;
}
#ifdef __cplusplus  
}  
#endif
