// EmbeddedDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PTCtlsReaderTest.h"
#include "EmbeddedDlg.h"


// CEmbeddedDlg �Ի���

IMPLEMENT_DYNAMIC(CEmbeddedDlg, CDialog)

CEmbeddedDlg::CEmbeddedDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEmbeddedDlg::IDD, pParent)
{
	pea_card_connect = NULL;
	pea_card_disconnect = NULL;
	pea_card_addpre = NULL;
	pea_card_addscript = NULL;
	pea_card_delpre = NULL;
	pea_card_delscript = NULL;
	pea_card_listpre = NULL;
	pea_card_listscript = NULL;
	pea_card_initpre = NULL;
	pea_card_runpre = NULL;
	pea_card_exitpre = NULL;
	memset(&ReaderObj, 0, sizeof(card_obj_t));
}

CEmbeddedDlg::~CEmbeddedDlg()
{
}

void CEmbeddedDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CEmbeddedDlg, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_EA_CONNECT, &CEmbeddedDlg::OnBnClickedButtonEaConnect)
	ON_BN_CLICKED(IDC_BUTTON_EA_DISCONNECT, &CEmbeddedDlg::OnBnClickedButtonEaDisconnect)
	ON_BN_CLICKED(IDC_BUTTON_EA_ADD_SCRIPT, &CEmbeddedDlg::OnBnClickedButtonEaAddScript)
	ON_BN_CLICKED(IDC_BUTTON_EA_ADD_PRE, &CEmbeddedDlg::OnBnClickedButtonAddPre)
	ON_BN_CLICKED(IDC_BUTTON_EA_LIST_SCRIPT, &CEmbeddedDlg::OnBnClickedButtonEaListScript)
	ON_BN_CLICKED(IDC_BUTTON_EA_LIST_PRE, &CEmbeddedDlg::OnBnClickedButtonEaListPre)
	ON_BN_CLICKED(IDC_BUTTON_EA_DEL_SCRIPT, &CEmbeddedDlg::OnBnClickedButtonEaDelScript)
	ON_BN_CLICKED(IDC_BUTTON_EA_DEL_PRE, &CEmbeddedDlg::OnBnClickedButtonEaDelPre)
	ON_BN_CLICKED(IDC_BUTTON_EA_INIT_PRE, &CEmbeddedDlg::OnBnClickedButtonEaInitPre)
	ON_BN_CLICKED(IDC_BUTTON_EA_RUN_PRE, &CEmbeddedDlg::OnBnClickedButtonEaRunPre)
	ON_BN_CLICKED(IDC_BUTTON_EA_EXIT_PRE, &CEmbeddedDlg::OnBnClickedButtonEaExitPre)
	ON_BN_CLICKED(IDC_BUTTON_EA_LOAD_SCRIPT, &CEmbeddedDlg::OnBnClickedButtonEaLoadScript)
	ON_BN_CLICKED(IDC_BUTTON_EA_LOAD_PRE, &CEmbeddedDlg::OnBnClickedButtonEaLoadPre)
END_MESSAGE_MAP()

BOOL CEmbeddedDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	SetDlgItemText(IDC_READER_IP, "192.168.1.1");
	GetDlgItem(IDC_READER_IP)->EnableWindow(TRUE);
	GetDlgItem(IDC_BUTTON_EA_CONNECT)->EnableWindow(TRUE);
	GetDlgItem(IDC_BUTTON_EA_DISCONNECT)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_EA_ADD_SCRIPT)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_EA_ADD_PRE)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_EA_DEL_SCRIPT)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_EA_DEL_PRE)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_EA_LIST_SCRIPT)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_EA_LIST_PRE)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_EA_INIT_PRE)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_EA_RUN_PRE)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_EA_EXIT_PRE)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_EA_LOAD_SCRIPT)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_EA_LOAD_PRE)->EnableWindow(FALSE);
	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

// CEmbeddedDlg ��Ϣ��������

void CEmbeddedDlg::OnBnClickedButtonEaConnect()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;
	CString m_ip;
	char ip[20] = {0};

	GetDlgItem(IDC_BUTTON_EA_CONNECT)->EnableWindow(FALSE);
	GetDlgItemText(IDC_READER_IP, m_ip);
	
	memcpy(ip, m_ip, m_ip.GetLength());
	ret = pea_card_connect(&ReaderObj, (UINT8 *)ip);
	if (ret != 0) {
		m_Output.AppendFormat("Connect Reader Failed[Err:%02x]\r\n", ret);
		GetDlgItem(IDC_BUTTON_EA_CONNECT)->EnableWindow(TRUE);
	} else {
		GetDlgItem(IDC_READER_IP)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_EA_DISCONNECT)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_EA_ADD_SCRIPT)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_EA_ADD_PRE)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_EA_DEL_SCRIPT)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_EA_DEL_PRE)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_EA_LIST_SCRIPT)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_EA_LIST_PRE)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_EA_INIT_PRE)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_EA_RUN_PRE)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_EA_EXIT_PRE)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_EA_LOAD_SCRIPT)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_EA_LOAD_PRE)->EnableWindow(TRUE);
		((CComboBox *)GetDlgItem(IDC_COMBO_EA_SCRIPT_NAME))->ResetContent();
		((CComboBox *)GetDlgItem(IDC_COMBO_EA_PRE_NAME))->ResetContent();
		m_Output.AppendFormat("Connect Reader Successed\r\n");
	}
	//SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	//m_Tab.DeleteItem(0);
	UpdateWindow();
}

void CEmbeddedDlg::OnBnClickedButtonEaDisconnect()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;

	ret = pea_card_disconnect(&ReaderObj);
	if (ret != 0) {
		m_Output.AppendFormat("Disconnect Reader Failed[Err:%02x]\r\n", ret);
	} else {
		GetDlgItem(IDC_READER_IP)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_EA_DISCONNECT)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_EA_ADD_SCRIPT)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_EA_ADD_PRE)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_EA_DEL_SCRIPT)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_EA_DEL_PRE)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_EA_LIST_SCRIPT)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_EA_LIST_PRE)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_EA_INIT_PRE)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_EA_RUN_PRE)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_EA_EXIT_PRE)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_EA_LOAD_SCRIPT)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_EA_LOAD_PRE)->EnableWindow(FALSE);
		((CComboBox *)GetDlgItem(IDC_COMBO_EA_SCRIPT_NAME))->ResetContent();
		((CComboBox *)GetDlgItem(IDC_COMBO_EA_PRE_NAME))->ResetContent();
		m_Output.AppendFormat("Disconnect Reader Successed\r\n");
	}
	GetDlgItem(IDC_BUTTON_EA_CONNECT)->EnableWindow(TRUE);
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	//m_Tab.InsertItem(0,_T("Command Mode"));
	UpdateWindow();
}

void CEmbeddedDlg::OnBnClickedButtonEaAddScript()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString path;
	CString script;
	int ret = 0;
	Uint8_t buf[2048] = {0};
	Uint8_t md5[32] = {0};
	Uint8_t name[64] = {0};
	Uint8_t force = 0;

	GetDlgItemText(IDC_EDIT_EA_SCRIPT_PATH, path);
	GetDlgItemText(IDC_EDIT_EA_SCRIPT_NAME, script);
	path.Trim();
	script.Trim();
	memset(buf, 0, sizeof(buf));
	memcpy(buf, path, path.GetLength());
	memset(md5, 0, sizeof(md5));
	memset(name, 0, sizeof(name));
	memcpy(name, script, script.GetLength());

	if (path == "") {
		m_Output.AppendFormat("Please Load Script Path\r\n");
		SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
		GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
		UpdateWindow();
		return;
	}
	if (script == "") {
		m_Output.AppendFormat("Please Input Script Name\r\n");
		SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
		GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
		UpdateWindow();
		return;
	}
	force = ((CButton *)GetDlgItem(IDC_CHECK_EA_ADD_SCRIPT_FORCE))->GetCheck();
	ret = pea_card_addscript(&ReaderObj, buf, name, md5, force);
	if (ret == 0) {
		m_Output.AppendFormat("Add Script Successed\r\n");
	} else {
		m_Output.AppendFormat("Add Script Failed[Err:%02x]\r\n", ret);
	}
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CEmbeddedDlg::OnBnClickedButtonAddPre()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString path;
	CString pre;
	int ret = 0;
	Uint8_t buf[2048] = {0};
	Uint8_t md5[32] = {0};
	Uint8_t name[64] = {0};
	Uint8_t force = 0;

	GetDlgItemText(IDC_EDIT_EA_PRE_PATH, path);
	GetDlgItemText(IDC_EDIT_EA_PRE_NAME, pre);
	path.Trim();
	pre.Trim();
	memset(buf, 0, sizeof(buf));
	memcpy(buf, path, path.GetLength());
	memset(md5, 0, sizeof(md5));
	memset(name, 0, sizeof(name));
	memcpy(name, pre, pre.GetLength());

	if (path == "") {
		m_Output.AppendFormat("Please Load Pre Path\r\n");
		SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
		GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
		UpdateWindow();
		return;
	}
	if (pre == "") {
		m_Output.AppendFormat("Please Input Pre Name\r\n");
		SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
		GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
		UpdateWindow();
		return;
	}

	force = ((CButton *)GetDlgItem(IDC_CHECK_EA_ADD_PRE_FORCE))->GetCheck();
	ret = pea_card_addpre(&ReaderObj, buf, name, md5, force);
	if (ret == 0) {
		m_Output.AppendFormat("Add Pre Successed\r\n");
	} else {
		m_Output.AppendFormat("Add Pre Failed[Err:%02x]\r\n", ret);
	}
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CEmbeddedDlg::OnBnClickedButtonEaListScript()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	Uint8_t ucNameList[2048] = {0};
	Uint32_t usListLen = 0;
	char *Name = NULL;
	int ret = 0;

	((CComboBox *)GetDlgItem(IDC_COMBO_EA_SCRIPT_NAME))->ResetContent();
	ret = pea_card_listscript(&ReaderObj, ucNameList, sizeof(ucNameList), &usListLen);
	if (ret == 0) {
		m_Output.AppendFormat("List Script Name Successed [%s]\r\n", ucNameList);
	} else {
		m_Output.AppendFormat("List Script Name Failed[Err:%02x]\r\n", ret);
	}
	if (usListLen > 0) {
		Name = strtok((char *)ucNameList, ",");
		while (Name != NULL) {
			((CComboBox *)GetDlgItem(IDC_COMBO_EA_SCRIPT_NAME))->AddString(Name);
			Name = strtok(NULL, ",");
		}
	}
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CEmbeddedDlg::OnBnClickedButtonEaListPre()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	Uint8_t ucNameList[2048] = {0};
	Uint32_t usListLen = 0;
	char *Name = NULL;
	int ret = 0;

	((CComboBox *)GetDlgItem(IDC_COMBO_EA_PRE_NAME))->ResetContent();
	ret = pea_card_listpre(&ReaderObj, ucNameList, sizeof(ucNameList), &usListLen);
	if (ret == 0) {
		m_Output.AppendFormat("List Pre Name Successed [%s]\r\n", ucNameList);
	} else {
		m_Output.AppendFormat("List Pre Name Failed[Err:%02x]\r\n", ret);
	}
	if (usListLen > 0) {
		Name = strtok((char *)ucNameList, ",");
		while (Name != NULL) {
			((CComboBox *)GetDlgItem(IDC_COMBO_EA_PRE_NAME))->AddString(Name);
			Name = strtok(NULL, ",");
		}
	}
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CEmbeddedDlg::OnBnClickedButtonEaDelScript()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;
	CString cScript;
	Uint8_t ucName[64] = {0};

	GetDlgItemText(IDC_COMBO_EA_SCRIPT_NAME, cScript);
	cScript.Trim();
	if (cScript == "") {
		m_Output.AppendFormat("Please Select Script Name\r\n");
		GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
		UpdateWindow();
		return;
	}
	memcpy(ucName, cScript, cScript.GetLength());
	ret = pea_card_delscript(&ReaderObj, ucName);
	if (ret == 0) {
		m_Output.AppendFormat("Delete Script %s Successed\r\n", ucName);
	} else {
		m_Output.AppendFormat("Delete Script %s Failed[Err:%02x]\r\n", ucName, ret);
	}
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CEmbeddedDlg::OnBnClickedButtonEaDelPre()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;
	CString cPre;
	Uint8_t ucName[64] = {0};

	GetDlgItemText(IDC_COMBO_EA_PRE_NAME, cPre);
	cPre.Trim();
	if (cPre == "") {
		m_Output.AppendFormat("Please Select PRE Name\r\n");
		GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
		UpdateWindow();
		return;
	}
	memcpy(ucName, cPre, cPre.GetLength());
	ret = pea_card_delpre(&ReaderObj, ucName);
	if (ret == 0) {
		m_Output.AppendFormat("Delete Pre %s Successed\r\n", ucName);
	} else {
		m_Output.AppendFormat("Delete Pre %s Failed[Err:%02x]\r\n", ucName, ret);
	}
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CEmbeddedDlg::OnBnClickedButtonEaInitPre()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;
	CString cPre;
	CString cScript;
	CString cInput;
	Uint8_t ucPreName[64] = {0};
	Uint8_t ucScriptName[64] = {0};
	Uint8_t *ucScriptNameP = NULL;
	Uint8_t ucInput[256] = {0};
	Uint8_t ucOutput[1024] = {0};
	Uint32_t OutputLen = sizeof(ucOutput);
	Uint32_t InputLen = 0;

	GetDlgItemText(IDC_COMBO_EA_SCRIPT_NAME, cScript);
	GetDlgItemText(IDC_COMBO_EA_PRE_NAME, cPre);
	GetDlgItemText(IDC_EDIT_EA_INIT_PRE_INPUT, cInput);
	cScript.Trim();
	cPre.Trim();
	cInput.Trim();

	if (cPre == "") {
		m_Output.AppendFormat("Please Select PRE Name\r\n");
		GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
		UpdateWindow();
		return;
	}
	if (cScript != "") {
		memcpy(ucScriptName, cScript, cScript.GetLength());
		ucScriptNameP = ucScriptName;
	} else {
		ucScriptNameP = NULL;
	}
	memcpy(ucPreName, cPre, cPre.GetLength());
	if (cInput != "") {
		memcpy(ucInput, cInput, cInput.GetLength());
		InputLen = cInput.GetLength() + 1;
	}
	ret = pea_card_initpre(&ReaderObj, ucPreName, ucScriptNameP, ucInput, InputLen, ucOutput, &OutputLen);
	if (ret == 0) {
		m_Output.AppendFormat("Init PRE Successed.Output:[%s]\r\n", ucOutput);
	} else {
		m_Output.AppendFormat("Init PRE Failed[Err:%02x].Output:[%s]\r\n", ret, ucOutput);
	}
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CEmbeddedDlg::OnBnClickedButtonEaRunPre()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;
	CString cInput;
	Uint8_t ucInput[256] = {0};
	Uint8_t ucOutput[1024] = {0};
	Uint32_t OutputLen = sizeof(ucOutput);
	Uint32_t InputLen = 0;

	GetDlgItemText(IDC_EDIT_EA_INIT_PRE_INPUT, cInput);
	cInput.Trim();
	if (cInput != "") {
		memcpy(ucInput, cInput, cInput.GetLength());
		InputLen = cInput.GetLength() + 1;
	}
	ret = pea_card_runpre(&ReaderObj, ucInput, InputLen, ucOutput, &OutputLen);
	if (ret == 0) {
		m_Output.AppendFormat("Run PRE Successed.Output:[%s]\r\n", ucOutput);
	} else {
		m_Output.AppendFormat("Run PRE Failed[Err:%02x].Output:[%s]\r\n", ret, ucOutput);
	}
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CEmbeddedDlg::OnBnClickedButtonEaExitPre()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;
	Uint8_t ucOutput[1024] = {0};
	Uint32_t OutputLen = sizeof(ucOutput);

	ret = pea_card_exitpre(&ReaderObj, ucOutput, &OutputLen);
	if (ret == 0) {
		m_Output.AppendFormat("Exit PRE Successed.Output:[%s]\r\n", ucOutput);
	} else {
		m_Output.AppendFormat("Exit PRE Failed[Err:%02x].Output:[%s]\r\n", ret, ucOutput);
	}
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CEmbeddedDlg::OnBnClickedButtonEaLoadScript()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	char *szFilter = {0};

	szFilter = new char[2048];
	sprintf(szFilter,"Files (*.txt)|*.TXT|ALLFILE(*.*)|*.*||");
	CFileDialog fd(TRUE,NULL,NULL,0,szFilter);
	if (IDOK != fd.DoModal())
		return;
	GetDlgItem(IDC_EDIT_EA_SCRIPT_PATH)->SetWindowText(fd.GetPathName());
	delete[] szFilter;
}

void CEmbeddedDlg::OnBnClickedButtonEaLoadPre()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	char *szFilter = {0};

	szFilter = new char[2048];
	sprintf(szFilter,"Files (*.pre)|*.pre|ALLFILE(*.*)|*.*||");
	CFileDialog fd(TRUE,NULL,NULL,0,szFilter);
	if (IDOK != fd.DoModal())
		return;
	GetDlgItem(IDC_EDIT_EA_PRE_PATH)->SetWindowText(fd.GetPathName());
	delete[] szFilter;
}

