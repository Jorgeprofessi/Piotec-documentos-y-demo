#pragma once
#include "pt_card.h"

typedef card_err_t ( *pCard_Open)(card_obj_t *obj, card_mod_t model, Uint8_t *addr);
typedef card_err_t ( *pCard_Close)(card_obj_t *obj);
typedef card_err_t ( *pCard_Reset)(card_obj_t *obj);
typedef card_err_t ( *pCard_PPS)(card_obj_t *obj, Uint8_t param1, Uint8_t param2);
typedef card_err_t ( *pCard_Off)(card_obj_t *obj);
typedef card_err_t ( *pCard_Apdu)(card_obj_t *obj, Uint8_t *tbuf, Uint16_t tlen, Uint8_t *rbuf, Uint16_t *rlen);
typedef card_err_t ( *pCard_GetInfo)(card_obj_t *obj, Uint8_t *info);
typedef card_err_t ( *pCard_AutoModel)(card_obj_t * obj);
typedef card_err_t ( *pCard_SetModel)(card_obj_t *obj, card_mod_t model);
typedef card_err_t ( *pCard_GetModel)(card_obj_t *obj, card_mod_t *model);
typedef card_err_t ( *pCard_SetFreq)(card_obj_t *obj, Uint16_t freq);
typedef card_err_t ( *pCard_GetFreq)(card_obj_t *obj, Uint16_t *freq);

// CBaseDlg �Ի���

class CBaseDlg : public CDialog
{
	DECLARE_DYNAMIC(CBaseDlg)

public:
	CBaseDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CBaseDlg();

// �Ի�������
	enum { IDD = IDD_BASE_MODE_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	pCard_Open pcard_open;
	pCard_Close pcard_close;
	pCard_Reset pcard_reset;
	pCard_Apdu pcard_apdu;
	pCard_GetInfo pcard_getinfo;
	pCard_PPS pcard_pps;
	pCard_AutoModel pcard_automodel;
	pCard_SetModel pcard_setmodel;
	pCard_GetModel pcard_getmodel;
	CString m_Output;
	card_obj_t ReaderObj;
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedButtonOpen();
	afx_msg void OnBnClickedButtonClose();
	afx_msg void OnBnClickedButtonReset();
	afx_msg void OnBnClickedButtonApdu();
	afx_msg void OnBnClickedButtonVersion();
	afx_msg void OnBnClickedButtonClear2();
	afx_msg void OnBnClickedButtonPps();
public:
	afx_msg void OnBnClickedButtonSetProtocol();
public:
	afx_msg void OnBnClickedButtonAutoProtocol();
public:
	afx_msg void OnBnClickedButtonGetProtocol();
};
