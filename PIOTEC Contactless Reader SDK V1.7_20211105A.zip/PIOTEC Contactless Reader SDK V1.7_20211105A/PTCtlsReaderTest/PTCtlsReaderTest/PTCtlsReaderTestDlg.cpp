// PTCtlsReaderTestDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PTCtlsReaderTest.h"
#include "PTCtlsReaderTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// ����Ӧ�ó��򡰹��ڡ��˵���� CAboutDlg �Ի���

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// �Ի�������
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

// ʵ��
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CPTCtlsReaderTestDlg �Ի���




CPTCtlsReaderTestDlg::CPTCtlsReaderTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPTCtlsReaderTestDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDI_PIOTEC_ICON);
	pcard_open = NULL;
	pcard_close = NULL;
	pcard_reset = NULL;
	pcard_apdu = NULL;
	pcard_getinfo = NULL;
	pcard_pps = NULL;
	pcard_automodel = NULL;
	pcard_setmodel = NULL;
	pcard_getmodel = NULL;

	pcard_reqa = NULL;
	pcard_wupa = NULL;
	pcard_anticol = NULL;
	pcard_select = NULL;
	pcard_halta = NULL;
	pcard_rats = NULL;
	pcard_reqb = NULL;
	pcard_wupb = NULL;
	pcard_attrib = NULL;
	pcard_haltb = NULL;
	pcard_deselect = NULL;
	pcard_getdetect = NULL;
	pcard_getid = NULL;
	pcard_setattribinf = NULL;
	pcard_getattribinf = NULL;
	pcard_authenticate = NULL;
	pcard_mifare_read = NULL;
	pcard_mifare_write = NULL;

	pea_card_connect = NULL;
	pea_card_disconnect = NULL;
	pea_card_addpre = NULL;
	pea_card_addscript = NULL;
	pea_card_delpre = NULL;
	pea_card_delscript = NULL;
	pea_card_listpre = NULL;
	pea_card_listscript = NULL;
	pea_card_initpre = NULL;
	pea_card_runpre = NULL;
	pea_card_exitpre = NULL;
}

void CPTCtlsReaderTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_MODE_TAB, m_Tab);
}

BEGIN_MESSAGE_MAP(CPTCtlsReaderTestDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_CLEAR, &CPTCtlsReaderTestDlg::OnBnClickedButtonClear)
	ON_NOTIFY(TCN_SELCHANGE, IDC_MODE_TAB, &CPTCtlsReaderTestDlg::OnTcnSelchangeModeTab)
END_MESSAGE_MAP()


// CPTCtlsReaderTestDlg ��Ϣ��������

BOOL CPTCtlsReaderTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// ��������...���˵������ӵ�ϵͳ�˵��С�

	// IDM_ABOUTBOX ������ϵͳ���Χ�ڡ�
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	// TODO: �ڴ����Ӷ���ĳ�ʼ������
	if (LoadPTCtlsReaderCtrlDll() < 0) {
		OnCancel();	
		return FALSE;
	}

	m_Tab.InsertItem(0,_T("Command Mode(Base)"));
	m_Tab.InsertItem(1,_T("Command Mode(Advanced)"));
	m_Tab.InsertItem(2,_T("Embedded Mode"));
	m_BaseDlg.Create(IDD_BASE_MODE_DIALOG, &m_Tab);
	m_AdvancedDlg.Create(IDD_ADVANCED_MODE_DIALOG, &m_Tab);
	m_EmbeddedDlg.Create(IDD_EMBEDDED_DIALOG, &m_Tab);

	//�趨��Tab����ʾ�ķ�Χ  
	CRect rc;  
	m_Tab.GetClientRect(rc);  
	rc.top+=30; 
	rc.bottom-=10; 
	rc.left+=1; 
	rc.right-=2; 
	m_BaseDlg.MoveWindow(&rc);
	m_AdvancedDlg.MoveWindow(&rc);
	m_EmbeddedDlg.MoveWindow(&rc); 
	pDialog[0] = &m_BaseDlg;
	pDialog[1] = &m_AdvancedDlg;
	pDialog[2] = &m_EmbeddedDlg;
	pDialog[0]->ShowWindow(SW_SHOW);
	pDialog[1]->ShowWindow(SW_HIDE);
	pDialog[2]->ShowWindow(SW_HIDE);
	m_CurSelTab = 0;

	m_BaseDlg.pcard_open = pcard_open;
	m_BaseDlg.pcard_close = pcard_close;
	m_BaseDlg.pcard_reset = pcard_reset;
	m_BaseDlg.pcard_apdu = pcard_apdu;
	m_BaseDlg.pcard_getinfo = pcard_getinfo;
	m_BaseDlg.pcard_pps = pcard_pps;
	m_BaseDlg.pcard_automodel = pcard_automodel;
	m_BaseDlg.pcard_setmodel = pcard_setmodel;
	m_BaseDlg.pcard_getmodel = pcard_getmodel;
	m_BaseDlg.m_Output = m_Output;

	m_AdvancedDlg.pcard_on = pcard_on;
	m_AdvancedDlg.pcard_off= pcard_off;
	m_AdvancedDlg.pcard_reqa = pcard_reqa;
	m_AdvancedDlg.pcard_wupa = pcard_wupa;
	m_AdvancedDlg.pcard_anticol = pcard_anticol;
	m_AdvancedDlg.pcard_select = pcard_select;
	m_AdvancedDlg.pcard_halta = pcard_halta;
	m_AdvancedDlg.pcard_rats = pcard_rats;
	m_AdvancedDlg.pcard_reqb = pcard_reqb;
	m_AdvancedDlg.pcard_wupb = pcard_wupb;
	m_AdvancedDlg.pcard_attrib = pcard_attrib;
	m_AdvancedDlg.pcard_haltb = pcard_haltb;
	m_AdvancedDlg.pcard_deselect = pcard_deselect;
	m_AdvancedDlg.pcard_getdetect = pcard_getdetect;
	m_AdvancedDlg.pcard_getid = pcard_getid;
	m_AdvancedDlg.pcard_setattribinf = pcard_setattribinf;
	m_AdvancedDlg.pcard_getattribinf = pcard_getattribinf;
	m_AdvancedDlg.pcard_authenticate = pcard_authenticate;
	m_AdvancedDlg.pcard_mifare_read = pcard_mifare_read;
	m_AdvancedDlg.pcard_mifare_write = pcard_mifare_write;
	m_AdvancedDlg.m_Output = m_Output;

	
	m_EmbeddedDlg.pea_card_connect = pea_card_connect;
	m_EmbeddedDlg.pea_card_disconnect = pea_card_disconnect;
	m_EmbeddedDlg.pea_card_addpre = pea_card_addpre;
	m_EmbeddedDlg.pea_card_addscript = pea_card_addscript;
	m_EmbeddedDlg.pea_card_delpre = pea_card_delpre;
	m_EmbeddedDlg.pea_card_delscript = pea_card_delscript;
	m_EmbeddedDlg.pea_card_listpre = pea_card_listpre;
	m_EmbeddedDlg.pea_card_listscript = pea_card_listscript;
	m_EmbeddedDlg.pea_card_initpre = pea_card_initpre;
	m_EmbeddedDlg.pea_card_runpre = pea_card_runpre;
	m_EmbeddedDlg.pea_card_exitpre = pea_card_exitpre;
	m_EmbeddedDlg.m_Output = m_Output;

	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

void CPTCtlsReaderTestDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CPTCtlsReaderTestDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ��������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù����ʾ��
//
HCURSOR CPTCtlsReaderTestDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


CString GetCtlsMoudlePath()
{
	char cPath[MAX_PATH];
	memset(cPath, 0, sizeof(cPath));
	//GetModuleFileName(AfxGetApp()->m_hInstance,cPath,MAX_PATH);
	GetModuleFileName(NULL, cPath, MAX_PATH);
	CString	strPath;
	strPath.Format("%s", cPath);
	int index = strPath.ReverseFind('\\');
	strPath.Delete(index + 1, strPath.GetLength() - 1 - index);
	return strPath;
}

int CPTCtlsReaderTestDlg::LoadPTCtlsReaderCtrlDll()
{
	CString strPTCardPath = GetCtlsMoudlePath() + "pt_card.dll";
	m_hPTCtlsCardInstance = NULL;

	m_hPTCtlsCardInstance = LoadLibrary(strPTCardPath);
	if (m_hPTCtlsCardInstance == NULL)
	{
		AfxMessageBox("Load pt_card.dll Failed!");
		return -1;
	}
	pcard_open = (pCard_Open)GetProcAddress(m_hPTCtlsCardInstance, "card_open");
	if (pcard_open == NULL)
	{
		AfxMessageBox("Load Function card_open Failed!");
		return -1;
	}
	pcard_close = (pCard_Close)GetProcAddress(m_hPTCtlsCardInstance, "card_close");
	if (pcard_close == NULL)
	{
		AfxMessageBox("Load Function card_close Failed!");
		return -1;
	}
	pcard_getinfo = (pCard_GetInfo)GetProcAddress(m_hPTCtlsCardInstance, "card_getinfo");
	if (pcard_getinfo == NULL)
	{
		AfxMessageBox("Load Function card_getnfo Failed!");
		return -1;
	}
	pcard_reset = (pCard_Reset)GetProcAddress(m_hPTCtlsCardInstance, "card_reset");
	if (pcard_reset == NULL)
	{
		AfxMessageBox("Load Function card_reset Failed!");
		return -1;
	}
	pcard_on = (pCard_On)GetProcAddress(m_hPTCtlsCardInstance, "card_on");
	if (pcard_on == NULL)
	{
		AfxMessageBox("Load Function card_on Failed!");
		return -1;
	}
	pcard_off = (pCard_Off)GetProcAddress(m_hPTCtlsCardInstance, "card_off");
	if (pcard_off == NULL)
	{
		AfxMessageBox("Load Function card_off Failed!");
		return -1;
	}
	pcard_apdu = (pCard_Apdu)GetProcAddress(m_hPTCtlsCardInstance, "card_pipe");
	if (pcard_apdu == NULL)
	{
		AfxMessageBox("Load Function card_apdu Failed!");
		return -1;
	}
	pcard_pps = (pCard_PPS)GetProcAddress(m_hPTCtlsCardInstance, "card_pps");
	if (pcard_pps == NULL)
	{
		AfxMessageBox("Load Function card_pps Failed!");
		return -1;
	}
	pcard_setmodel = (pCard_SetModel)GetProcAddress(m_hPTCtlsCardInstance, "card_setmodel");
	if (pcard_setmodel == NULL)
	{
		AfxMessageBox("Load Function card_setmodel Failed!");
		return -1;
	}
	pcard_getmodel = (pCard_GetModel)GetProcAddress(m_hPTCtlsCardInstance, "card_getmodel");
	if (pcard_getmodel == NULL)
	{
		AfxMessageBox("Load Function card_getmodel Failed!");
		return -1;
	}
	pcard_automodel = (pCard_AutoModel)GetProcAddress(m_hPTCtlsCardInstance, "card_automodel");
	if (pcard_automodel == NULL)
	{
		AfxMessageBox("Load Function card_automodel Failed!");
		return -1;
	}
	pcard_setfreq = (pCard_SetFreq)GetProcAddress(m_hPTCtlsCardInstance, "card_setfreq");
	if (pcard_setfreq == NULL)
	{
		AfxMessageBox("Load Function card_setfreq Failed!");
		return -1;
	}
	pcard_getfreq = (pCard_GetFreq)GetProcAddress(m_hPTCtlsCardInstance, "card_getfreq");
	if (pcard_getfreq == NULL)
	{
		AfxMessageBox("Load Function card_getfreq Failed!");
		return -1;
	}
	pcard_reqa = (pCard_Reqa)GetProcAddress(m_hPTCtlsCardInstance, "card_reqa");
	if (pcard_reqa == NULL)
	{
		AfxMessageBox("Load Function card_reqa Failed!");
		return -1;
	}
	pcard_wupa = (pCard_Wupa)GetProcAddress(m_hPTCtlsCardInstance, "card_wupa");
	if (pcard_wupa == NULL)
	{
		AfxMessageBox("Load Function card_wupa Failed!");
		return -1;
	}
	pcard_anticol = (pCard_Anticol)GetProcAddress(m_hPTCtlsCardInstance, "card_anticol");
	if (pcard_anticol == NULL)
	{
		AfxMessageBox("Load Function card_anticol Failed!");
		return -1;
	}
	pcard_select = (pCard_Select)GetProcAddress(m_hPTCtlsCardInstance, "card_select");
	if (pcard_select == NULL)
	{
		AfxMessageBox("Load Function card_select Failed!");
		return -1;
	}
	pcard_halta = (pCard_Halta)GetProcAddress(m_hPTCtlsCardInstance, "card_halta");
	if (pcard_halta == NULL)
	{
		AfxMessageBox("Load Function card_halta Failed!");
		return -1;
	}
	pcard_rats = (pCard_Rats)GetProcAddress(m_hPTCtlsCardInstance, "card_rats");
	if (pcard_rats == NULL)
	{
		AfxMessageBox("Load Function card_rats Failed!");
		return -1;
	}
	pcard_reqb = (pCard_Reqb)GetProcAddress(m_hPTCtlsCardInstance, "card_reqb");
	if (pcard_reqb == NULL)
	{
		AfxMessageBox("Load Function card_reqb Failed!");
		return -1;
	}
	pcard_wupb = (pCard_Wupb)GetProcAddress(m_hPTCtlsCardInstance, "card_wupb");
	if (pcard_wupb == NULL)
	{
		AfxMessageBox("Load Function card_wupb Failed!");
		return -1;
	}
	pcard_attrib = (pCard_Attrib)GetProcAddress(m_hPTCtlsCardInstance, "card_attrib");
	if (pcard_attrib == NULL)
	{
		AfxMessageBox("Load Function card_attrib Failed!");
		return -1;
	}
	pcard_haltb = (pCard_Haltb)GetProcAddress(m_hPTCtlsCardInstance, "card_haltb");
	if (pcard_haltb == NULL)
	{
		AfxMessageBox("Load Function card_haltb Failed!");
		return -1;
	}
	pcard_deselect = (pCard_Deselect)GetProcAddress(m_hPTCtlsCardInstance, "card_deselect");
	if (pcard_deselect == NULL)
	{
		AfxMessageBox("Load Function card_deselect Failed!");
		return -1;
	}

	pcard_getdetect = (pCard_GetDetect)GetProcAddress(m_hPTCtlsCardInstance, "card_getdetect");
	if (pcard_getdetect == NULL)
	{
		AfxMessageBox("Load Function card_getdetect Failed!");
		return -1;
	}
	pcard_getid = (pCard_GetId)GetProcAddress(m_hPTCtlsCardInstance, "card_getid");
	if (pcard_getid == NULL)
	{
		AfxMessageBox("Load Function card_getid Failed!");
		return -1;
	}
	pcard_setattribinf = (pCard_SetAttribInf)GetProcAddress(m_hPTCtlsCardInstance, "card_setattribinf");
	if (pcard_setattribinf == NULL)
	{
		AfxMessageBox("Load Function card_setattribinf Failed!");
		return -1;
	}
	pcard_getattribinf = (pCard_GetAttribInf)GetProcAddress(m_hPTCtlsCardInstance, "card_getattribinf");
	if (pcard_getattribinf == NULL)
	{
		AfxMessageBox("Load Function card_getattribinf Failed!");
		return -1;
	}
	pcard_authenticate = (pCard_Authenticate)GetProcAddress(m_hPTCtlsCardInstance, "card_authenticate");
	if (pcard_authenticate == NULL)
	{
		AfxMessageBox("Load Function card_authenticate Failed!");
		return -1;
	}

	pcard_mifare_read = (pCard_Mifare_Read)GetProcAddress(m_hPTCtlsCardInstance, "card_mifare_read");
	if (pcard_mifare_read == NULL)
	{
		AfxMessageBox("Load Function card_mifare_read Failed!");
		return -1;
	}

	pcard_mifare_write = (pCard_Mifare_Write)GetProcAddress(m_hPTCtlsCardInstance, "card_mifare_write");
	if (pcard_mifare_write == NULL)
	{
		AfxMessageBox("Load Function card_mifare_write Failed!");
		return -1;
	}

	pea_card_connect = (pea_Card_Connect)GetProcAddress(m_hPTCtlsCardInstance, "ea_card_connect");
	if (pea_card_connect == NULL)
	{
		AfxMessageBox("Load Function ea_card_connect Failed!");
		return -1;
	}
	pea_card_disconnect = (pea_Card_Disconnect)GetProcAddress(m_hPTCtlsCardInstance, "ea_card_disconnect");
	if (pea_card_disconnect == NULL)
	{
		AfxMessageBox("Load Function ea_card_disconnect Failed!");
		return -1;
	}
	pea_card_addpre = (pea_Card_AddPRE)GetProcAddress(m_hPTCtlsCardInstance, "ea_card_addpre");
	if (pea_card_addpre == NULL)
	{
		AfxMessageBox("Load Function ea_card_addpre Failed!");
		return -1;
	}
	pea_card_addscript = (pea_Card_AddScript)GetProcAddress(m_hPTCtlsCardInstance, "ea_card_addscript");
	if (pea_card_addscript == NULL)
	{
		AfxMessageBox("Load Function ea_card_addscript Failed!");
		return -1;
	}
	pea_card_delpre = (pea_Card_DelPRE)GetProcAddress(m_hPTCtlsCardInstance, "ea_card_delpre");
	if (pea_card_delpre == NULL)
	{
		AfxMessageBox("Load Function ea_card_delpre Failed!");
		return -1;
	}
	pea_card_delscript = (pea_Card_DelScript)GetProcAddress(m_hPTCtlsCardInstance, "ea_card_delscript");
	if (pea_card_delscript == NULL)
	{
		AfxMessageBox("Load Function ea_card_delscript Failed!");
		return -1;
	}
	pea_card_listpre = (pea_Card_ListPRE)GetProcAddress(m_hPTCtlsCardInstance, "ea_card_listpre");
	if (pea_card_listpre == NULL)
	{
		AfxMessageBox("Load Function ea_card_listpre Failed!");
		return -1;
	}
	pea_card_listscript = (pea_Card_ListScript)GetProcAddress(m_hPTCtlsCardInstance, "ea_card_listscript");
	if (pea_card_listscript == NULL)
	{
		AfxMessageBox("Load Function ea_card_listscript Failed!");
		return -1;
	}
	pea_card_initpre = (pea_Card_InitPRE)GetProcAddress(m_hPTCtlsCardInstance, "ea_card_initpre");
	if (pea_card_initpre == NULL)
	{
		AfxMessageBox("Load Function ea_card_initpre Failed!");
		return -1;
	}
	pea_card_runpre = (pea_Card_RunPRE)GetProcAddress(m_hPTCtlsCardInstance, "ea_card_runpre");
	if (pea_card_runpre == NULL)
	{
		AfxMessageBox("Load Function ea_card_runpre Failed!");
		return -1;
	}
	pea_card_exitpre = (pea_Card_ExitPRE)GetProcAddress(m_hPTCtlsCardInstance, "ea_card_exitpre");
	if (pea_card_exitpre == NULL)
	{
		AfxMessageBox("Load Function ea_card_exitpre Failed!");
		return -1;
	}
	return 0;
}

void CPTCtlsReaderTestDlg::OnBnClickedButtonClear()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	m_BaseDlg.m_Output.Empty();
	m_AdvancedDlg.m_Output.Empty();
	m_EmbeddedDlg.m_Output.Empty();
	m_Output.Empty();
	SetDlgItemText(IDC_EDIT_OUTPUT, "");
	UpdateWindow();
}
void CPTCtlsReaderTestDlg::OnTcnSelchangeModeTab(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	pDialog[m_CurSelTab]->ShowWindow(SW_HIDE);
	m_CurSelTab = m_Tab.GetCurSel();
	pDialog[m_CurSelTab]->ShowWindow(SW_SHOW);
	if (m_CurSelTab == 0)
		m_BaseDlg.m_Output = m_AdvancedDlg.m_Output;
	else if (m_CurSelTab == 1)
		m_AdvancedDlg.m_Output = m_BaseDlg.m_Output;
	else
		m_EmbeddedDlg.m_Output = m_BaseDlg.m_Output;
	*pResult = 0;
}
