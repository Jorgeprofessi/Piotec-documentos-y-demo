#pragma once
#include "pt_card.h"

typedef card_err_t ( *pCard_On)(card_obj_t *obj);
typedef card_err_t ( *pCard_Off)(card_obj_t *obj);
typedef card_err_t ( *pCard_Reqa)(card_obj_t *obj, Uint16_t *atqa);
typedef card_err_t ( *pCard_Wupa)(card_obj_t *obj, Uint16_t *atqa);
typedef card_err_t ( *pCard_Anticol)(card_obj_t *obj, Uint8_t *uid, Uint16_t *uid_len, Uint8_t *sak, Uint8_t *status);
typedef card_err_t ( *pCard_Select)(card_obj_t *obj, Uint8_t *uid, Uint16_t uid_len, Uint8_t *sak);
typedef card_err_t ( *pCard_Halta)(card_obj_t *obj);
typedef card_err_t ( *pCard_Rats)(card_obj_t *obj, Uint8_t *ats, Uint16_t *ats_len);
typedef card_err_t ( *pCard_Reqb)(card_obj_t *obj, Uint8_t *atqb, Uint8_t *atqb_len);
typedef card_err_t ( *pCard_Wupb)(card_obj_t *obj, Uint8_t *atqb, Uint8_t *atqb_len);
typedef card_err_t ( *pCard_Attrib)(card_obj_t *obj, Uint8_t *rbuf, Uint16_t *rlen);
typedef card_err_t ( *pCard_Haltb)(card_obj_t *obj);
typedef card_err_t ( *pCard_Deselect)(card_obj_t *obj);
typedef card_err_t ( *pCard_GetDetect)(card_obj_t *obj, Uint8_t *val);
typedef card_err_t ( *pCard_GetId)(card_obj_t *obj, Uint8_t *id, Uint8_t *id_len);
typedef card_err_t ( *pCard_SetAttribInf)(card_obj_t *obj, Uint8_t *tbuf, Uint16_t tlen);
typedef card_err_t ( *pCard_GetAttribInf)(card_obj_t *obj, Uint8_t *rbuf, Uint16_t *rlen);
typedef card_err_t ( *pCard_Authenticate)(card_obj_t *obj, Uint8_t block_no, Uint8_t key_type, Uint8_t *key, Uint8_t *uid);
typedef card_err_t ( *pCard_Mifare_Read)(card_obj_t *obj, Uint8_t block_no, Uint8_t *rbuf);
typedef card_err_t ( *pCard_Mifare_Write)(card_obj_t *obj, Uint8_t block_no, Uint8_t *tbuf);

// CAdvancedDlg �Ի���

class CAdvancedDlg : public CDialog
{
	DECLARE_DYNAMIC(CAdvancedDlg)

public:
	CAdvancedDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CAdvancedDlg();

// �Ի�������
	enum { IDD = IDD_ADVANCED_MODE_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	pCard_On pcard_on;
	pCard_Off pcard_off;
	pCard_Reqa pcard_reqa;
	pCard_Wupa pcard_wupa;
	pCard_Anticol pcard_anticol;
	pCard_Select pcard_select;
	pCard_Halta pcard_halta;
	pCard_Rats pcard_rats;
	pCard_Reqb pcard_reqb;
	pCard_Wupb pcard_wupb;
	pCard_Attrib pcard_attrib;
	pCard_Haltb pcard_haltb;
	pCard_Deselect pcard_deselect;
	pCard_GetDetect pcard_getdetect;
	pCard_GetId pcard_getid;
	pCard_SetAttribInf pcard_setattribinf;
	pCard_GetAttribInf pcard_getattribinf;
	pCard_Authenticate pcard_authenticate;
	pCard_Mifare_Read pcard_mifare_read;
	pCard_Mifare_Write pcard_mifare_write;
	CString m_Output;
	card_obj_t ReaderObj;
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedButtonRfon();
	afx_msg void OnBnClickedButtonRfoff();
public:
	afx_msg void OnBnClickedButtonGetId();
public:
	afx_msg void OnBnClickedButtonReqa();
public:
	afx_msg void OnBnClickedButtonWupa();
public:
	afx_msg void OnBnClickedButtonAnticol();
public:
	afx_msg void OnBnClickedButtonHalta();
public:
	afx_msg void OnBnClickedButtonSelect();
public:
	afx_msg void OnBnClickedButtonRats();
public:
	afx_msg void OnBnClickedButtonDeselect();
public:
	afx_msg void OnBnClickedButtonDetect();
public:
	afx_msg void OnBnClickedButtonMAuth();
public:
	afx_msg void OnBnClickedButtonReqb();
public:
	afx_msg void OnBnClickedButtonWupb();
public:
	afx_msg void OnBnClickedButtonAttrib();
public:
	afx_msg void OnBnClickedButtonHaltb();
public:
	afx_msg void OnBnClickedButtonDeselect2();
public:
	afx_msg void OnBnClickedButtonDetect2();
public:
	afx_msg void OnBnClickedButtonGetAttribInf();
public:
	afx_msg void OnBnClickedButtonSetAttribInf();
public:
	afx_msg void OnEnChangeEditMBlockNo();
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
public:
	afx_msg void OnBnClickedButtonMRead();
public:
	afx_msg void OnBnClickedButtonMWrite();
};
