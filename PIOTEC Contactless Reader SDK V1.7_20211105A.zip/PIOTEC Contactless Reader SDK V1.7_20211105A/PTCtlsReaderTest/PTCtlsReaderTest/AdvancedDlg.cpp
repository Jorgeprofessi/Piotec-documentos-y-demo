// AdvancedDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PTCtlsReaderTest.h"
#include "AdvancedDlg.h"


// CAdvancedDlg �Ի���

IMPLEMENT_DYNAMIC(CAdvancedDlg, CDialog)

CAdvancedDlg::CAdvancedDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAdvancedDlg::IDD, pParent)
{
	pcard_reqa = NULL;
	pcard_wupa = NULL;
	pcard_anticol = NULL;
	pcard_select = NULL;
	pcard_halta = NULL;
	pcard_rats = NULL;
	pcard_reqb = NULL;
	pcard_wupb = NULL;
	pcard_attrib = NULL;
	pcard_haltb = NULL;
	pcard_deselect = NULL;
	pcard_getdetect = NULL;
	pcard_getid = NULL;
	pcard_setattribinf = NULL;
	pcard_getattribinf = NULL;
	pcard_authenticate = NULL;
	memset(&ReaderObj, 0, sizeof(card_obj_t));
}

CAdvancedDlg::~CAdvancedDlg()
{
}

void CAdvancedDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CAdvancedDlg, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_RFON, &CAdvancedDlg::OnBnClickedButtonRfon)
	ON_BN_CLICKED(IDC_BUTTON_RFOFF, &CAdvancedDlg::OnBnClickedButtonRfoff)
	ON_BN_CLICKED(IDC_BUTTON_GET_ID, &CAdvancedDlg::OnBnClickedButtonGetId)
	ON_BN_CLICKED(IDC_BUTTON_REQA, &CAdvancedDlg::OnBnClickedButtonReqa)
	ON_BN_CLICKED(IDC_BUTTON_WUPA, &CAdvancedDlg::OnBnClickedButtonWupa)
	ON_BN_CLICKED(IDC_BUTTON_ANTICOL, &CAdvancedDlg::OnBnClickedButtonAnticol)
	ON_BN_CLICKED(IDC_BUTTON_HALTA, &CAdvancedDlg::OnBnClickedButtonHalta)
	ON_BN_CLICKED(IDC_BUTTON_SELECT, &CAdvancedDlg::OnBnClickedButtonSelect)
	ON_BN_CLICKED(IDC_BUTTON_RATS, &CAdvancedDlg::OnBnClickedButtonRats)
	ON_BN_CLICKED(IDC_BUTTON_DESELECT, &CAdvancedDlg::OnBnClickedButtonDeselect)
	ON_BN_CLICKED(IDC_BUTTON_DETECT, &CAdvancedDlg::OnBnClickedButtonDetect)
	ON_BN_CLICKED(IDC_BUTTON_M_AUTH, &CAdvancedDlg::OnBnClickedButtonMAuth)
	ON_BN_CLICKED(IDC_BUTTON_REQB, &CAdvancedDlg::OnBnClickedButtonReqb)
	ON_BN_CLICKED(IDC_BUTTON_WUPB, &CAdvancedDlg::OnBnClickedButtonWupb)
	ON_BN_CLICKED(IDC_BUTTON_ATTRIB, &CAdvancedDlg::OnBnClickedButtonAttrib)
	ON_BN_CLICKED(IDC_BUTTON_HALTB, &CAdvancedDlg::OnBnClickedButtonHaltb)
	ON_BN_CLICKED(IDC_BUTTON_DESELECT2, &CAdvancedDlg::OnBnClickedButtonDeselect2)
	ON_BN_CLICKED(IDC_BUTTON_DETECT2, &CAdvancedDlg::OnBnClickedButtonDetect2)
	ON_BN_CLICKED(IDC_BUTTON_GET_ATTRIB_INF, &CAdvancedDlg::OnBnClickedButtonGetAttribInf)
	ON_BN_CLICKED(IDC_BUTTON_SET_ATTRIB_INF, &CAdvancedDlg::OnBnClickedButtonSetAttribInf)
	ON_EN_CHANGE(IDC_EDIT_M_BLOCK_NO, &CAdvancedDlg::OnEnChangeEditMBlockNo)
	ON_BN_CLICKED(IDC_BUTTON_M_READ, &CAdvancedDlg::OnBnClickedButtonMRead)
	ON_BN_CLICKED(IDC_BUTTON_M_WRITE, &CAdvancedDlg::OnBnClickedButtonMWrite)
END_MESSAGE_MAP()


// CAdvancedDlg ��Ϣ��������

BOOL CAdvancedDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	GetDlgItem(IDC_BUTTON_RFON)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_RFOFF)->EnableWindow(FALSE);
	//Advanced
	GetDlgItem(IDC_BUTTON_GET_ID)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_REQA)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_WUPA)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_ANTICOL)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_HALTA)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_REQB)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_WUPB)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_ATTRIB)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_HALTB)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_SELECT)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_DESELECT)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_DESELECT2)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_DETECT)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_DETECT2)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_M_AUTH)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_M_READ)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_M_WRITE)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_RATS)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_GET_ATTRIB_INF)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_SET_ATTRIB_INF)->EnableWindow(FALSE);

	((CButton *)GetDlgItem(IDC_RADIO_M_KEYA))->SetCheck(TRUE);
	GetDlgItem(IDC_RADIO_M_KEYA)->EnableWindow(FALSE);
	GetDlgItem(IDC_RADIO_M_KEYB)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_M_UID)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_M_BLOCK_NO)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_M_KEY1)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_M_KEY2)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_M_KEY3)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_M_KEY4)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_M_KEY5)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_M_KEY6)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_M_WRITE)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_SELECT_UID)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_ATTRIB_INF)->EnableWindow(FALSE);


	SetDlgItemInt(IDC_EDIT_M_BLOCK_NO, 0);
	((CEdit*)GetDlgItem(IDC_EDIT_M_KEY1))->SetLimitText(2);
	((CEdit*)GetDlgItem(IDC_EDIT_M_KEY2))->SetLimitText(2);
	((CEdit*)GetDlgItem(IDC_EDIT_M_KEY3))->SetLimitText(2);
	((CEdit*)GetDlgItem(IDC_EDIT_M_KEY4))->SetLimitText(2);
	((CEdit*)GetDlgItem(IDC_EDIT_M_KEY5))->SetLimitText(2);
	((CEdit*)GetDlgItem(IDC_EDIT_M_KEY6))->SetLimitText(2);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CAdvancedDlg::OnBnClickedButtonRfon()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;

	ret = pcard_on(&ReaderObj);
	if (ret != 0) {
		m_Output.AppendFormat("RF On Failed[Err:%02x]\r\n", ret);
	} else {
		m_Output.AppendFormat("RF On Successed\r\n");
	}
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CAdvancedDlg::OnBnClickedButtonRfoff()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;

	ret = pcard_off(&ReaderObj);
	if (ret != 0) {
		m_Output.AppendFormat("RF Off Failed[Err:%02x]\r\n", ret);
	} else {
		m_Output.AppendFormat("RF Off Successed\r\n");
	}
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CAdvancedDlg::OnBnClickedButtonGetId()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;
	Uint8_t ucId[64];
	Uint8_t ucIdLen = 0;
	char Id[64];
	int i = 0;

	memset(ucId, 0, sizeof(ucId));
	memset(Id, 0, sizeof(Id));
	ret = pcard_getid(&ReaderObj, ucId, &ucIdLen);
	if (ret != 0) {
		m_Output.AppendFormat("Get ID Failed[Err:%02x]\r\n", ret);
	} else {
		for (i = 0; i < ucIdLen; i++) {
			sprintf(Id + i * 2, "%02x", ucId[i]);
		}
		m_Output.AppendFormat("Get ID Successed.ID[%s]\r\n", Id);
	}
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CAdvancedDlg::OnBnClickedButtonReqa()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;
	Uint16_t ucAtqa;

	ret = pcard_reqa(&ReaderObj, &ucAtqa);
	if (ret != 0) {
		m_Output.AppendFormat("Card Reqa Failed[Err:%02x]\r\n", ret);
	} else {
		m_Output.AppendFormat("Card Reqa Successed.ATQA[%02x%02x]\r\n", (ucAtqa >> 8) & 0xFF, ucAtqa & 0xFF);
	}
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CAdvancedDlg::OnBnClickedButtonWupa()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;
	Uint16_t ucAtqa;

	ret = pcard_wupa(&ReaderObj, &ucAtqa);
	if (ret != 0) {
		m_Output.AppendFormat("Card Wupa Failed[Err:%02x]\r\n", ret);
	} else {
		m_Output.AppendFormat("Card Wupa Successed.ATQA[%02x%02x]\r\n", (ucAtqa >> 8) & 0xFF, ucAtqa & 0xFF);
	}
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CAdvancedDlg::OnBnClickedButtonAnticol()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;
	Uint8_t ucUid[64];
	Uint16_t usUidLen;
	Uint8_t ucSak;
	Uint8_t ucStatus;
	char Uid[64];
	int i = 0;

	memset(ucUid, 0, sizeof(ucUid));
	memset(Uid, 0, sizeof(Uid));
	ret = pcard_anticol(&ReaderObj, ucUid, &usUidLen, &ucSak, &ucStatus);
	if (ret != 0) {
		m_Output.AppendFormat("Card Anticol Failed[Err:%02x]\r\n", ret);
	} else {
		for (i = 0; i < usUidLen; i++) {
			sprintf(Uid + i * 2, "%02x", ucUid[i]);
		}
		m_Output.AppendFormat("Card Anticol Successed.UID[%s]/Sak[%02x]/Status[%d]\r\n", Uid, ucSak, ucStatus);
	}
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CAdvancedDlg::OnBnClickedButtonHalta()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;

	ret = pcard_halta(&ReaderObj);
	if (ret != 0) {
		m_Output.AppendFormat("Card Halta Failed[Err:%02x]\r\n", ret);
	} else {
		m_Output.AppendFormat("Card Halta Successed\r\n");
	}
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CAdvancedDlg::OnBnClickedButtonSelect()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;
	CString cUid;
	Uint8_t ucUid[64];
	Uint16_t usUidLen = 0;
	Uint8_t ucSak;
	int i = 0;

	GetDlgItemText(IDC_EDIT_SELECT_UID, cUid);
	if (cUid == "") {
		m_Output.AppendFormat("Please Input UID\r\n");
		GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
		UpdateWindow();
		return;
	}
	memset(ucUid, 0, sizeof(ucUid));
	usUidLen = cUid.GetLength() / 2;
	for (i = 0; i < usUidLen; i++) {
		sscanf(cUid.GetBuffer() + 2 * i, "%02x", ucUid + i);
	}
	ret = pcard_select(&ReaderObj, ucUid, usUidLen, &ucSak);
	if (ret != 0) {
		m_Output.AppendFormat("Card Select Failed[Err:%02x]\r\n", ret);
	} else {
		m_Output.AppendFormat("Card Select Successed.Sak[%02x]\r\n", ucSak);
	}
	cUid.ReleaseBuffer();
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CAdvancedDlg::OnBnClickedButtonRats()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;
	Uint8_t ucAts[255];
	Uint16_t usAtsLen = 0;
	char Ats[255];
	int i = 0;

	memset(ucAts, 0, sizeof(ucAts));
	memset(Ats, 0, sizeof(Ats));
	ret = pcard_rats(&ReaderObj, ucAts, &usAtsLen);
	if (ret != 0) {
		m_Output.AppendFormat("Card Rats Failed[Err:%02x]\r\n", ret);
	} else {
		for (i = 0; i < usAtsLen; i++) {
			sprintf(Ats + i * 2, "%02x", ucAts[i]);
		}
		m_Output.AppendFormat("Card Rats Successed.ATS[%s]\r\n", Ats);
	}
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CAdvancedDlg::OnBnClickedButtonDeselect()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;

	ret = pcard_deselect(&ReaderObj);
	if (ret != 0) {
		m_Output.AppendFormat("Card Deselect Failed[Err:%02x]\r\n", ret);
	} else {
		m_Output.AppendFormat("Card Deselect Successed\r\n");
	}
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CAdvancedDlg::OnBnClickedButtonDetect()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;
	Uint8_t ucValue;

	ret = pcard_getdetect(&ReaderObj, &ucValue);
	if (ret != 0) {
		m_Output.AppendFormat("Card Get Detect Failed[Err:%02x]\r\n", ret);
	} else {
		m_Output.AppendFormat("Card Get Detect Successed.Value[%d]\r\n", ucValue);
	}
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CAdvancedDlg::OnBnClickedButtonMAuth()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	//A91D6B07
	int ret = 0;
	Uint8_t ucKeyType = 0x0A;
	CString cKey;
	CString cKeyByte;
	CString cUid;
	Uint8_t ucKey[16];
	Uint8_t ucUid[64];
	int BlockNo = 0;
	int i = 0;

	if (((CButton *)GetDlgItem(IDC_RADIO_M_KEYA))->GetCheck()) {
		ucKeyType = CARD_MIFARE_KEYA;
	} else if (((CButton *)GetDlgItem(IDC_RADIO_M_KEYB))->GetCheck()) {
		ucKeyType = CARD_MIFARE_KEYB;
	}
	BlockNo = GetDlgItemInt(IDC_EDIT_M_BLOCK_NO);
	GetDlgItemText(IDC_EDIT_M_UID, cUid);
	if (cUid == "") {
		m_Output.AppendFormat("Please Input UID\r\n");
		GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
		UpdateWindow();
		return;
	}
	GetDlgItemText(IDC_EDIT_M_KEY1, cKeyByte);
	cKey = cKeyByte;
	GetDlgItemText(IDC_EDIT_M_KEY2, cKeyByte);
	cKey += cKeyByte;
	GetDlgItemText(IDC_EDIT_M_KEY3, cKeyByte);
	cKey += cKeyByte;
	GetDlgItemText(IDC_EDIT_M_KEY4, cKeyByte);
	cKey += cKeyByte;
	GetDlgItemText(IDC_EDIT_M_KEY5, cKeyByte);
	cKey += cKeyByte;
	GetDlgItemText(IDC_EDIT_M_KEY6, cKeyByte);
	cKey += cKeyByte;
	if (cKey == "" || cKey.GetLength() != 12) {
		m_Output.AppendFormat("Please Input Correct Key\r\n");
		GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
		UpdateWindow();
		return;
	}
	memset(ucKey, 0, sizeof(ucKey));
	memset(ucUid, 0, sizeof(ucUid));
	for (i = 0; i < cKey.GetLength() / 2; i++) {
		sscanf(cKey.GetBuffer() + 2 * i, "%02x", ucKey + i);
	}
	for (i = 0; i < cUid.GetLength() / 2; i++) {
		sscanf(cUid.GetBuffer() + 2 * i, "%02x", ucUid + i);
	}
	ret = pcard_authenticate(&ReaderObj, (Uint8_t)BlockNo, ucKeyType, ucKey, ucUid);
	if (ret != 0) {
		m_Output.AppendFormat("Mifare Card Authenticate Failed[Err:%02x]\r\n", ret);
	} else {
		m_Output.AppendFormat("Mifare Card Authenticate Successed\r\n");
	}
	cKey.ReleaseBuffer();
	cUid.ReleaseBuffer();
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CAdvancedDlg::OnBnClickedButtonReqb()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;
	Uint8_t ucAtqb[255];
	Uint8_t ucAtqbLen = 0;
	char Atqb[255];
	int i = 0;

	memset(ucAtqb, 0, sizeof(ucAtqb));
	memset(Atqb, 0, sizeof(Atqb));
	ret = pcard_reqb(&ReaderObj, ucAtqb, &ucAtqbLen);
	if (ret != 0) {
		m_Output.AppendFormat("Card Reqb Failed[Err:%02x]\r\n", ret);
	} else {
		for (i = 0; i < ucAtqbLen; i++) {
			sprintf(Atqb + i * 2, "%02x", ucAtqb[i]);
		}
		m_Output.AppendFormat("Card Reqb Successed.ATQB[%s]\r\n", Atqb);
	}
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CAdvancedDlg::OnBnClickedButtonWupb()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;
	Uint8_t ucAtqb[255];
	Uint8_t ucAtqbLen = 0;
	char Atqb[255];
	int i = 0;

	memset(ucAtqb, 0, sizeof(ucAtqb));
	memset(Atqb, 0, sizeof(Atqb));
	ret = pcard_wupb(&ReaderObj, ucAtqb, &ucAtqbLen);
	if (ret != 0) {
		m_Output.AppendFormat("Card Wupb Failed[Err:%02x]\r\n", ret);
	} else {
		for (i = 0; i < ucAtqbLen; i++) {
			sprintf(Atqb + i * 2, "%02x", ucAtqb[i]);
		}
		m_Output.AppendFormat("Card Wupb Successed.ATQB[%s]\r\n", Atqb);
	}
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CAdvancedDlg::OnBnClickedButtonAttrib()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	
	int ret = 0;
	Uint8_t ucRecvBuf[256];
	Uint16_t usRecvBufLen = 0;
	char RecvBuf[256];
	int i = 0;

	memset(ucRecvBuf, 0, sizeof(ucRecvBuf));
	memset(RecvBuf, 0, sizeof(RecvBuf));
	ret = pcard_attrib(&ReaderObj, ucRecvBuf, &usRecvBufLen);
	if (ret != 0) {
		m_Output.AppendFormat("Card Attrib Failed[Err:%02x]\r\n", ret);
	} else {
		for (i = 0; i < usRecvBufLen; i++) {
			sprintf(RecvBuf + i * 2, "%02x", ucRecvBuf[i]);
		}
		m_Output.AppendFormat("Card Attrib Successed.Recv[%s]\r\n", RecvBuf);
	}
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CAdvancedDlg::OnBnClickedButtonHaltb()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;

	ret = pcard_haltb(&ReaderObj);
	if (ret != 0) {
		m_Output.AppendFormat("Card Haltb Failed[Err:%02x]\r\n", ret);
	} else {
		m_Output.AppendFormat("Card Haltb Successed\r\n");
	}
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CAdvancedDlg::OnBnClickedButtonDeselect2()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	OnBnClickedButtonDeselect();
}

void CAdvancedDlg::OnBnClickedButtonDetect2()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	OnBnClickedButtonDetect();
}

void CAdvancedDlg::OnBnClickedButtonGetAttribInf()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;
	Uint8_t ucRecvBuf[256];
	Uint16_t usRecvBufLen = 0;
	char RecvBuf[256];
	int i = 0;

	memset(ucRecvBuf, 0, sizeof(ucRecvBuf));
	memset(RecvBuf, 0, sizeof(RecvBuf));
	ret = pcard_getattribinf(&ReaderObj, ucRecvBuf, &usRecvBufLen);
	if (ret != 0) {
		m_Output.AppendFormat("Card Get INF Failed[Err:%02x]\r\n", ret);
	} else {
		for (i = 0; i < usRecvBufLen; i++) {
			sprintf(RecvBuf + i * 2, "%02x", ucRecvBuf[i]);
		}
		m_Output.AppendFormat("Card Get INF Successed.INF[%s]\r\n", RecvBuf);
	}
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CAdvancedDlg::OnBnClickedButtonSetAttribInf()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;
	CString cSendBuf;
	Uint8_t ucSendBuf[256];
	Uint16_t usSendBufLen = 0;
	int i = 0;

	GetDlgItemText(IDC_EDIT_ATTRIB_INF, cSendBuf);
	usSendBufLen = cSendBuf.GetLength() / 2;
	memset(ucSendBuf, 0, sizeof(ucSendBuf));
	for (i = 0; i < usSendBufLen; i++) {
		sscanf(cSendBuf.GetBuffer() + 2 * i, "%02x", ucSendBuf + i);
	}
	ret = pcard_setattribinf(&ReaderObj, ucSendBuf, usSendBufLen);
	if (ret != 0) {
		m_Output.AppendFormat("Card Set INF Failed[Err:%02x]\r\n", ret);
	} else {
		m_Output.AppendFormat("Card Set INF Successed\r\n");
	}
	cSendBuf.ReleaseBuffer();
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CAdvancedDlg::OnEnChangeEditMBlockNo()
{
	// TODO:  ����ÿؼ��� RICHEDIT �ؼ�������������
	// ���͸�֪ͨ��������д CDialog::OnInitDialog()
	// ���������� CRichEditCtrl().SetEventMask()��
	// ͬʱ�� ENM_CHANGE ��־�������㵽�����С�

	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	int BlockNo;

	BlockNo = GetDlgItemInt(IDC_EDIT_M_BLOCK_NO);
	if (BlockNo < 0 || BlockNo > 99)
		SetDlgItemInt(IDC_EDIT_M_BLOCK_NO, 0);
}

BOOL CAdvancedDlg::PreTranslateMessage(MSG* pMsg)
{
	// TODO: �ڴ�����ר�ô����/����û���
	if(pMsg->message==WM_CHAR)
	{

		//���ؼ��Ƿ��ǵ�ǰ����
		if(GetDlgItem(IDC_EDIT_M_KEY1) == GetFocus()||
			GetDlgItem(IDC_EDIT_M_KEY2) == GetFocus()||
			GetDlgItem(IDC_EDIT_M_KEY3) == GetFocus()||
			GetDlgItem(IDC_EDIT_M_KEY4) == GetFocus()||
			GetDlgItem(IDC_EDIT_M_KEY5) == GetFocus()||
			GetDlgItem(IDC_EDIT_M_KEY6) == GetFocus()||
			GetDlgItem(IDC_EDIT_M_UID) == GetFocus()||
			GetDlgItem(IDC_EDIT_SELECT_UID) == GetFocus()||
			GetDlgItem(IDC_EDIT_ATTRIB_INF) == GetFocus())
		{

			//���Ctrl��ϼ�
			int nks = GetKeyState(VK_CONTROL);
			if (nks & 0x8000)
			{
				return CDialog::PreTranslateMessage(pMsg);
			}
			//������������
			if ((pMsg->wParam >= 0x30 && pMsg->wParam <=  0x39) ||
				(pMsg->wParam  >= 'a' && pMsg->wParam  <= 'f') ||
				(pMsg->wParam  >= 'A' && pMsg->wParam  <= 'F') ||
				(pMsg->wParam  == 0x08) ||
				(pMsg->wParam  == 0x20))
			{
				return CDialog::PreTranslateMessage(pMsg);
			} 
			else
			{
				MessageBeep(-1);
				pMsg->wParam=NULL;
			}
		}
	}

	return CDialog::PreTranslateMessage(pMsg);
}

void CAdvancedDlg::OnBnClickedButtonMRead()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;
	Uint8_t ucRecvBuf[16];
	char RecvBuf[64];
	int i = 0;
	int BlockNo = 0;

	BlockNo = GetDlgItemInt(IDC_EDIT_M_BLOCK_NO);
	memset(ucRecvBuf, 0, sizeof(ucRecvBuf));
	memset(RecvBuf, 0, sizeof(RecvBuf));
	ret = pcard_mifare_read(&ReaderObj, BlockNo, ucRecvBuf);
	if (ret != 0) {
		m_Output.AppendFormat("Miafer Card Read Failed[Err:%02x]\r\n", ret);
	} else {
		for (i = 0; i < 16; i++) {
			sprintf(RecvBuf + i * 2, "%02x", ucRecvBuf[i]);
		}
		m_Output.AppendFormat("Miafer Card Read Successed.Recv[%s]\r\n", RecvBuf);
	}
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CAdvancedDlg::OnBnClickedButtonMWrite()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;
	CString cSendBuf;
	Uint8_t ucSendBuf[256];
	Uint16_t usSendBufLen = 0;
	int i = 0;
	int BlockNo = 0;

	BlockNo = GetDlgItemInt(IDC_EDIT_M_BLOCK_NO);
	GetDlgItemText(IDC_EDIT_M_WRITE, cSendBuf);
	usSendBufLen = cSendBuf.GetLength() / 2;
	if (usSendBufLen != 16)
	{
		m_Output.AppendFormat("Data Length Error.Please Input Correct Data\r\n");
		GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
		UpdateWindow();
		return;
	}
	memset(ucSendBuf, 0, sizeof(ucSendBuf));
	for (i = 0; i < usSendBufLen; i++) {
		sscanf(cSendBuf.GetBuffer() + 2 * i, "%02x", ucSendBuf + i);
	}
	ret = pcard_mifare_write(&ReaderObj, BlockNo, ucSendBuf);
	if (ret != 0) {
		m_Output.AppendFormat("Miafer Card Write Failed[Err:%02x]\r\n", ret);
	} else {
		m_Output.AppendFormat("Miafer Card Write Successed\r\n");
	}
	cSendBuf.ReleaseBuffer();
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}