// BaseDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PTCtlsReaderTest.h"
#include "BaseDlg.h"
#include "AdvancedDlg.h"
#include "EmbeddedDlg.h"

// CBaseDlg �Ի���

IMPLEMENT_DYNAMIC(CBaseDlg, CDialog)

CBaseDlg::CBaseDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CBaseDlg::IDD, pParent)
{
	pcard_open = NULL;
	pcard_close = NULL;
	pcard_reset = NULL;
	pcard_apdu = NULL;
	pcard_getinfo = NULL;
	pcard_pps = NULL;
	pcard_automodel = NULL;
	pcard_setmodel = NULL;
	pcard_getmodel = NULL;
	memset(&ReaderObj, 0, sizeof(card_obj_t));
}

CBaseDlg::~CBaseDlg()
{
}

void CBaseDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CBaseDlg, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_OPEN, &CBaseDlg::OnBnClickedButtonOpen)
	ON_BN_CLICKED(IDC_BUTTON_CLOSE, &CBaseDlg::OnBnClickedButtonClose)
	ON_BN_CLICKED(IDC_BUTTON_RESET, &CBaseDlg::OnBnClickedButtonReset)
	ON_BN_CLICKED(IDC_BUTTON_APDU, &CBaseDlg::OnBnClickedButtonApdu)
	ON_BN_CLICKED(IDC_BUTTON_VERSION, &CBaseDlg::OnBnClickedButtonVersion)
	ON_BN_CLICKED(IDC_BUTTON_CLEAR2, &CBaseDlg::OnBnClickedButtonClear2)
	ON_BN_CLICKED(IDC_BUTTON_PPS, &CBaseDlg::OnBnClickedButtonPps)
	ON_BN_CLICKED(IDC_BUTTON_SET_PROTOCOL, &CBaseDlg::OnBnClickedButtonSetProtocol)
	ON_BN_CLICKED(IDC_BUTTON_AUTO_PROTOCOL, &CBaseDlg::OnBnClickedButtonAutoProtocol)
	ON_BN_CLICKED(IDC_BUTTON_GET_PROTOCOL, &CBaseDlg::OnBnClickedButtonGetProtocol)
END_MESSAGE_MAP()


// CBaseDlg ��Ϣ��������

BOOL CBaseDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	SetDlgItemText(IDC_READER_IP, "192.168.1.1");
	GetDlgItem(IDC_BUTTON_CLOSE)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_VERSION)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_RESET)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_APDU)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_PPS)->EnableWindow(FALSE);
	GetDlgItem(IDC_COMBO_DRI)->EnableWindow(FALSE);
	GetDlgItem(IDC_COMBO_DSI)->EnableWindow(FALSE);
	GetDlgItem(IDC_COMBO_PROTOCOL)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_SET_PROTOCOL)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_GET_PROTOCOL)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_AUTO_PROTOCOL)->EnableWindow(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}


void CBaseDlg::OnBnClickedButtonOpen()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;
	CString m_ip;
	char ip[20] = {0};


	GetDlgItem(IDC_BUTTON_OPEN)->EnableWindow(FALSE);
	GetDlgItemText(IDC_READER_IP, m_ip);
	memcpy(ip, m_ip, m_ip.GetLength());
	ret = pcard_open(&ReaderObj, MODEL_P14443A, (UINT8 *)ip);
	if (ret != 0) {
		m_Output.AppendFormat("Open Reader Failed[Err:%02x]\r\n", ret);
		GetDlgItem(IDC_BUTTON_OPEN)->EnableWindow(TRUE);
	} else {
		GetDlgItem(IDC_READER_IP)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_CLOSE)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_VERSION)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_RESET)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_APDU)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_PPS)->EnableWindow(TRUE);
		GetDlgItem(IDC_COMBO_DRI)->EnableWindow(TRUE);
		GetDlgItem(IDC_COMBO_DSI)->EnableWindow(TRUE);
		GetDlgItem(IDC_COMBO_PROTOCOL)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_SET_PROTOCOL)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_GET_PROTOCOL)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_AUTO_PROTOCOL)->EnableWindow(TRUE);

		CWnd *page_adv = GetParent()->GetWindow(GW_CHILD)->GetWindow(GW_HWNDNEXT);
		memcpy(&((CAdvancedDlg*)page_adv)->ReaderObj, &ReaderObj, sizeof(card_obj_t));
		page_adv->GetDlgItem(IDC_BUTTON_RFON)->EnableWindow(TRUE);
		page_adv->GetDlgItem(IDC_BUTTON_RFOFF)->EnableWindow(TRUE);
		page_adv->GetDlgItem(IDC_BUTTON_GET_ID)->EnableWindow(TRUE);
		//14443A
		page_adv->GetDlgItem(IDC_BUTTON_REQA)->EnableWindow(TRUE);
		page_adv->GetDlgItem(IDC_BUTTON_WUPA)->EnableWindow(TRUE);
		page_adv->GetDlgItem(IDC_BUTTON_ANTICOL)->EnableWindow(TRUE);
		page_adv->GetDlgItem(IDC_BUTTON_HALTA)->EnableWindow(TRUE);
		page_adv->GetDlgItem(IDC_BUTTON_SELECT)->EnableWindow(TRUE);
		page_adv->GetDlgItem(IDC_BUTTON_RATS)->EnableWindow(TRUE);
		page_adv->GetDlgItem(IDC_BUTTON_DESELECT)->EnableWindow(TRUE);
		page_adv->GetDlgItem(IDC_BUTTON_DETECT)->EnableWindow(TRUE);
		page_adv->GetDlgItem(IDC_EDIT_SELECT_UID)->EnableWindow(TRUE);
		//14443B
		page_adv->GetDlgItem(IDC_BUTTON_REQB)->EnableWindow(TRUE);
		page_adv->GetDlgItem(IDC_BUTTON_WUPB)->EnableWindow(TRUE);
		page_adv->GetDlgItem(IDC_BUTTON_ATTRIB)->EnableWindow(TRUE);
		page_adv->GetDlgItem(IDC_BUTTON_HALTB)->EnableWindow(TRUE);
		page_adv->GetDlgItem(IDC_BUTTON_DESELECT2)->EnableWindow(TRUE);
		page_adv->GetDlgItem(IDC_BUTTON_DETECT2)->EnableWindow(TRUE);
		page_adv->GetDlgItem(IDC_BUTTON_GET_ATTRIB_INF)->EnableWindow(TRUE);
		page_adv->GetDlgItem(IDC_BUTTON_SET_ATTRIB_INF)->EnableWindow(TRUE);
		page_adv->GetDlgItem(IDC_EDIT_ATTRIB_INF)->EnableWindow(TRUE);
		//MIFARE
		page_adv->GetDlgItem(IDC_BUTTON_M_AUTH)->EnableWindow(TRUE);
		page_adv->GetDlgItem(IDC_BUTTON_M_READ)->EnableWindow(TRUE);
		page_adv->GetDlgItem(IDC_BUTTON_M_WRITE)->EnableWindow(TRUE);
		page_adv->GetDlgItem(IDC_RADIO_M_KEYA)->EnableWindow(TRUE);
		page_adv->GetDlgItem(IDC_RADIO_M_KEYB)->EnableWindow(TRUE);
		page_adv->GetDlgItem(IDC_EDIT_M_UID)->EnableWindow(TRUE);
		page_adv->GetDlgItem(IDC_EDIT_M_BLOCK_NO)->EnableWindow(TRUE);
		page_adv->GetDlgItem(IDC_EDIT_M_KEY1)->EnableWindow(TRUE);
		page_adv->GetDlgItem(IDC_EDIT_M_KEY2)->EnableWindow(TRUE);
		page_adv->GetDlgItem(IDC_EDIT_M_KEY3)->EnableWindow(TRUE);
		page_adv->GetDlgItem(IDC_EDIT_M_KEY4)->EnableWindow(TRUE);
		page_adv->GetDlgItem(IDC_EDIT_M_KEY5)->EnableWindow(TRUE);
		page_adv->GetDlgItem(IDC_EDIT_M_KEY6)->EnableWindow(TRUE);
		page_adv->GetDlgItem(IDC_EDIT_M_WRITE)->EnableWindow(TRUE);

		CWnd *page_emb = GetParent()->GetWindow(GW_CHILD)->GetWindow(GW_HWNDNEXT)->GetWindow(GW_HWNDNEXT);
		page_emb->GetDlgItem(IDC_BUTTON_EA_CONNECT)->EnableWindow(FALSE);
		page_emb->GetDlgItem(IDC_READER_IP)->EnableWindow(FALSE);

		m_Output.AppendFormat("Open Reader Successed\r\n");
		// Get Current Protocol
		OnBnClickedButtonGetProtocol();
	}
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}


void CBaseDlg::OnBnClickedButtonClose()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;

	ret = pcard_close(&ReaderObj);
	if (ret != 0) {
		m_Output.AppendFormat("Close Reader Failed[Err:%02x]\r\n", ret);
	} else {
		GetDlgItem(IDC_BUTTON_CLOSE)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_VERSION)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_RESET)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_APDU)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_PPS)->EnableWindow(FALSE);
		GetDlgItem(IDC_COMBO_DRI)->EnableWindow(FALSE);
		GetDlgItem(IDC_COMBO_DSI)->EnableWindow(FALSE);
		GetDlgItem(IDC_COMBO_PROTOCOL)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_SET_PROTOCOL)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_GET_PROTOCOL)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_AUTO_PROTOCOL)->EnableWindow(FALSE);

		CWnd *page_adv = GetParent()->GetWindow(GW_CHILD)->GetWindow(GW_HWNDNEXT);
		page_adv->GetDlgItem(IDC_BUTTON_RFON)->EnableWindow(FALSE);
		page_adv->GetDlgItem(IDC_BUTTON_RFOFF)->EnableWindow(FALSE);
		//Advanced
		page_adv->GetDlgItem(IDC_BUTTON_GET_ID)->EnableWindow(FALSE);
		page_adv->GetDlgItem(IDC_BUTTON_REQA)->EnableWindow(FALSE);
		page_adv->GetDlgItem(IDC_BUTTON_WUPA)->EnableWindow(FALSE);
		page_adv->GetDlgItem(IDC_BUTTON_ANTICOL)->EnableWindow(FALSE);
		page_adv->GetDlgItem(IDC_BUTTON_HALTA)->EnableWindow(FALSE);
		page_adv->GetDlgItem(IDC_BUTTON_REQB)->EnableWindow(FALSE);
		page_adv->GetDlgItem(IDC_BUTTON_WUPB)->EnableWindow(FALSE);
		page_adv->GetDlgItem(IDC_BUTTON_ATTRIB)->EnableWindow(FALSE);
		page_adv->GetDlgItem(IDC_BUTTON_HALTB)->EnableWindow(FALSE);
		page_adv->GetDlgItem(IDC_BUTTON_SELECT)->EnableWindow(FALSE);
		page_adv->GetDlgItem(IDC_BUTTON_DESELECT)->EnableWindow(FALSE);
		page_adv->GetDlgItem(IDC_BUTTON_DESELECT2)->EnableWindow(FALSE);
		page_adv->GetDlgItem(IDC_BUTTON_DETECT)->EnableWindow(FALSE);
		page_adv->GetDlgItem(IDC_BUTTON_DETECT2)->EnableWindow(FALSE);
		page_adv->GetDlgItem(IDC_BUTTON_M_AUTH)->EnableWindow(FALSE);
		page_adv->GetDlgItem(IDC_BUTTON_RATS)->EnableWindow(FALSE);
		page_adv->GetDlgItem(IDC_BUTTON_GET_ATTRIB_INF)->EnableWindow(FALSE);
		page_adv->GetDlgItem(IDC_BUTTON_SET_ATTRIB_INF)->EnableWindow(FALSE);

		page_adv->GetDlgItem(IDC_RADIO_M_KEYA)->EnableWindow(FALSE);
		page_adv->GetDlgItem(IDC_RADIO_M_KEYB)->EnableWindow(FALSE);
		page_adv->GetDlgItem(IDC_EDIT_M_UID)->EnableWindow(FALSE);
		page_adv->GetDlgItem(IDC_EDIT_M_BLOCK_NO)->EnableWindow(FALSE);
		page_adv->GetDlgItem(IDC_EDIT_M_KEY1)->EnableWindow(FALSE);
		page_adv->GetDlgItem(IDC_EDIT_M_KEY2)->EnableWindow(FALSE);
		page_adv->GetDlgItem(IDC_EDIT_M_KEY3)->EnableWindow(FALSE);
		page_adv->GetDlgItem(IDC_EDIT_M_KEY4)->EnableWindow(FALSE);
		page_adv->GetDlgItem(IDC_EDIT_M_KEY5)->EnableWindow(FALSE);
		page_adv->GetDlgItem(IDC_EDIT_M_KEY6)->EnableWindow(FALSE);
		page_adv->GetDlgItem(IDC_EDIT_SELECT_UID)->EnableWindow(FALSE);
		page_adv->GetDlgItem(IDC_EDIT_ATTRIB_INF)->EnableWindow(FALSE);

		CWnd *page_emb = GetParent()->GetWindow(GW_CHILD)->GetWindow(GW_HWNDNEXT)->GetWindow(GW_HWNDNEXT);
		page_emb->GetDlgItem(IDC_BUTTON_EA_CONNECT)->EnableWindow(TRUE);
		page_emb->GetDlgItem(IDC_READER_IP)->EnableWindow(TRUE);
		m_Output.AppendFormat("Close Reader Successed\r\n");
	}
	GetDlgItem(IDC_READER_IP)->EnableWindow(TRUE);
	GetDlgItem(IDC_BUTTON_OPEN)->EnableWindow(TRUE);
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CBaseDlg::OnBnClickedButtonReset()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;
	char ats[128];
	int i = 0;

	memset(ats, 0, sizeof(ats));
	ret = pcard_reset(&ReaderObj);
	if (ret != 0) {
		m_Output.AppendFormat("Reset Failed[Err:%02x]\r\n", ret);
	} else {
		for (i = 0; i < ReaderObj.atr_len; i++) {
			sprintf(ats + i * 2, "%02x", ReaderObj.atr[i]);
		}
		m_Output.AppendFormat("Reset Successed[ATS:%s]\r\n", ats);
	}
	CWnd *page_adv = GetParent()->GetWindow(GW_CHILD)->GetWindow(GW_HWNDNEXT);
	memcpy(&((CAdvancedDlg*)page_adv)->ReaderObj, &ReaderObj, sizeof(card_obj_t));
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}


void CBaseDlg::OnBnClickedButtonApdu()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;
	int i = 0;
	char cSend[1024];
	Uint8_t Send[1024];
	int nSend = 0;
	Uint16_t SendLen = 0;
	char cRecv[1024];
	Uint8_t Recv[1024];
	Uint16_t RecvLen = 0;
	int pos = 0;
	CString cDataAll;
	CString cData;

	GetDlgItemText(IDC_EDIT_INPUT, cDataAll);
	cData = cDataAll.Tokenize("\r\n", pos);
	if (cData == "") {
		m_Output.AppendFormat("No Data\r\n");
		GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
		UpdateWindow();
		return;
	}
	do {
		memset(cSend, 0, sizeof(cSend));
		memset(cRecv, 0, sizeof(cRecv));
		memset(Send, 0, sizeof(Send));
		memset(Recv, 0, sizeof(Recv));
		memcpy(cSend, cData.GetBuffer(), cData.GetLength());
		SendLen = cData.GetLength() / 2;
		for (i = 0; i < SendLen; i++) {
			sscanf(cSend + 2 * i, "%02x", &nSend);
			Send[i] = (Uint8_t)nSend;
		}
		ret = pcard_apdu(&ReaderObj, Send, SendLen, Recv, &RecvLen);
		if (ret != 0) {
			m_Output.AppendFormat("Write Data Failed[Err:%02x]\r\n", ret);
		} else {
			for (i = 0; i < RecvLen; i++) {
				sprintf(cRecv + i * 2, "%02x", Recv[i]);
			}
			m_Output.AppendFormat("[Recv:%s]\r\n", cRecv);
		}
		cData = cDataAll.Tokenize("\r\n", pos);
	} while (cData != "");
	CWnd *page_adv = GetParent()->GetWindow(GW_CHILD)->GetWindow(GW_HWNDNEXT);
	memcpy(&((CAdvancedDlg*)page_adv)->ReaderObj, &ReaderObj, sizeof(card_obj_t));
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}


void CBaseDlg::OnBnClickedButtonVersion()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;
	Uint8_t info[128];

	memset(info, 0, sizeof(info));
	ret = pcard_getinfo(&ReaderObj, info);
	if (ret != 0) {
		m_Output.AppendFormat("Get Version Failed[Err:%02x]\r\n", ret);
	}
	else {
		m_Output.AppendFormat("Get Version Successed[Ver:%s]\r\n", info);
	}
	CWnd *page_adv = GetParent()->GetWindow(GW_CHILD)->GetWindow(GW_HWNDNEXT);
	memcpy(&((CAdvancedDlg*)page_adv)->ReaderObj, &ReaderObj, sizeof(card_obj_t));
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CBaseDlg::OnBnClickedButtonPps()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;
	CComboBox *cb_dri;
	CComboBox *cb_dsi;
	int m_dri;
	int m_dsi;
	Uint8_t ucPPS[5] = { 0 };
	CString cDRI;
	CString cDSI;

	cb_dri = (CComboBox *)GetDlgItem(IDC_COMBO_DRI);
	cb_dsi = (CComboBox *)GetDlgItem(IDC_COMBO_DSI);
	m_dri = cb_dri->GetCurSel();
	m_dsi = cb_dsi->GetCurSel();
	if (m_dri < 0 || m_dsi < 0) {
		m_Output.AppendFormat("No DRI or DSI\r\n");
		GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
		UpdateWindow();
		return;
	}
	GetDlgItemText(IDC_COMBO_DRI, cDRI);
	GetDlgItemText(IDC_COMBO_DSI, cDSI);
	ret = pcard_pps(&ReaderObj, m_dri, m_dsi);
	if (ret != 0) {
		m_Output.AppendFormat("Set PPS Failed[Err:%02x]\r\n", ret);
	} else {
		m_Output.AppendFormat("Set PPS Successed[DRI:%s DSI:%s]\r\n", cDRI, cDSI);
	}
	CWnd *page_adv = GetParent()->GetWindow(GW_CHILD)->GetWindow(GW_HWNDNEXT);
	memcpy(&((CAdvancedDlg*)page_adv)->ReaderObj, &ReaderObj, sizeof(card_obj_t));
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CBaseDlg::OnBnClickedButtonSetProtocol()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;
	CString model;
	card_mod_t ucModel;

	GetDlgItemText(IDC_COMBO_PROTOCOL, model);
	if (model == "14443A") {
		ucModel = MODEL_P14443A;
	} else if (model == "14443B") {
		ucModel = MODEL_P14443B;
	} else if (model == "MIFARE") {
		ucModel = MODEL_PMIFARE;
	} else if (model == "FELICA") {
		ucModel = MODEL_PFELICA;
	} else if (model == "15693") {
		ucModel = MODEL_P15693;
	} else {
		m_Output.AppendFormat("Please Select Model\r\n");
		GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
		UpdateWindow();
		return;
	}
	ret = pcard_setmodel(&ReaderObj, ucModel);
	if (ret != 0) {
		m_Output.AppendFormat("Set Model Failed[Err:%02x]\r\n", ret);
	}
	else {
		m_Output.AppendFormat("Set Model Successed\r\n");
	}
	CWnd *page_adv = GetParent()->GetWindow(GW_CHILD)->GetWindow(GW_HWNDNEXT);
	memcpy(&((CAdvancedDlg*)page_adv)->ReaderObj, &ReaderObj, sizeof(card_obj_t));
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CBaseDlg::OnBnClickedButtonAutoProtocol()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;
	CString model;

	ret = pcard_automodel(&ReaderObj);
	if (ret != 0) {
		m_Output.AppendFormat("Auto Model Failed[Err:%02x]\r\n", ret);
	}
	else {
		if (ReaderObj.model == MODEL_P14443A) {
			model = _T("14443A");
		} else if (ReaderObj.model == MODEL_P14443B) {
			model = _T("14443B");
		} else if (ReaderObj.model == MODEL_PMIFARE) {
			model = _T("MIFARE");
		} else if (ReaderObj.model == MODEL_PFELICA) {
			model = _T("FELICA");
		} else if (ReaderObj.model == MODEL_P15693) {
			model = _T("15693");
		} else {
			model = "";
		}
		SetDlgItemText(IDC_COMBO_PROTOCOL, model);
		m_Output.AppendFormat("Auto Model Successed.Current Protocol is %s\r\n", model);
	}
	CWnd *page_adv = GetParent()->GetWindow(GW_CHILD)->GetWindow(GW_HWNDNEXT);
	memcpy(&((CAdvancedDlg*)page_adv)->ReaderObj, &ReaderObj, sizeof(card_obj_t));
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CBaseDlg::OnBnClickedButtonGetProtocol()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret = 0;
	CString model;
	card_mod_t ucModel;

	ret = pcard_getmodel(&ReaderObj, &ucModel);
	if (ret != 0) {
		m_Output.AppendFormat("Get Model Failed[Err:%02x]\r\n", ret);
	} else {
		if (ucModel == MODEL_P14443A) {
			model = _T("14443A");
		} else if (ucModel == MODEL_P14443B) {
			model = _T("14443B");
		} else if (ucModel == MODEL_PMIFARE) {
			model = _T("MIFARE");
		} else if (ucModel == MODEL_PFELICA) {
			model = _T("FELICA");
		} else if (ucModel == MODEL_P15693) {
			model = _T("15693");
		} else {
			model = "";
		}
		SetDlgItemText(IDC_COMBO_PROTOCOL, model);
		m_Output.AppendFormat("Get Model Successed.Current Protocol is %s\r\n", model);
	}
	CWnd *page_adv = GetParent()->GetWindow(GW_CHILD)->GetWindow(GW_HWNDNEXT);
	memcpy(&((CAdvancedDlg*)page_adv)->ReaderObj, &ReaderObj, sizeof(card_obj_t));
	GetParent()->GetParent()->SetDlgItemText(IDC_EDIT_OUTPUT, m_Output);
	UpdateWindow();
}

void CBaseDlg::OnBnClickedButtonClear2()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	SetDlgItemText(IDC_EDIT_INPUT, "");
	UpdateWindow();
}