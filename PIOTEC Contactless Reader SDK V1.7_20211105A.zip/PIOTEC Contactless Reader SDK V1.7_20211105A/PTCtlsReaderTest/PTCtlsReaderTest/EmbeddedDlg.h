#pragma once
#include "pt_card.h"

typedef card_err_t ( *pea_Card_Connect)(card_obj_t *obj, Uint8_t *addr);
typedef card_err_t ( *pea_Card_Disconnect)(card_obj_t *obj);
typedef card_err_t ( *pea_Card_AddPRE)(card_obj_t *obj, Uint8_t *path, Uint8_t *name, Uint8_t *md5, Uint8_t force);
typedef card_err_t ( *pea_Card_AddScript)(card_obj_t *obj, Uint8_t *path, Uint8_t *name, Uint8_t *md5, Uint8_t force);
typedef card_err_t ( *pea_Card_DelPRE)(card_obj_t *obj, Uint8_t *name);
typedef card_err_t ( *pea_Card_DelScript)(card_obj_t *obj, Uint8_t *name);
typedef card_err_t ( *pea_Card_ListPRE)(card_obj_t *obj, Uint8_t *list, Uint32_t list_len, Uint32_t *list_all_len);
typedef card_err_t ( *pea_Card_ListScript)(card_obj_t *obj, Uint8_t *list, Uint32_t list_len, Uint32_t *list_all_len);
typedef card_err_t ( *pea_Card_InitPRE)(card_obj_t *obj, Uint8_t *lib_name, Uint8_t *script_name, Uint8_t *user_data, Uint32_t user_data_len, Uint8_t *output_info, Uint32_t *output_info_len);
typedef card_err_t ( *pea_Card_RunPRE)(card_obj_t *obj, Uint8_t *user_data, Uint32_t user_data_len, Uint8_t *output_info, Uint32_t *output_info_len);
typedef card_err_t ( *pea_Card_ExitPRE)(card_obj_t *obj, Uint8_t *output_info, Uint32_t *output_info_len);
// CEmbeddedDlg �Ի���

class CEmbeddedDlg : public CDialog
{
	DECLARE_DYNAMIC(CEmbeddedDlg)

public:
	CEmbeddedDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CEmbeddedDlg();

// �Ի�������
	enum { IDD = IDD_EMBEDDED_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	pea_Card_Connect pea_card_connect;
	pea_Card_Disconnect pea_card_disconnect;
	pea_Card_AddPRE pea_card_addpre;
	pea_Card_AddScript pea_card_addscript;
	pea_Card_DelPRE pea_card_delpre;
	pea_Card_DelScript pea_card_delscript;
	pea_Card_ListPRE pea_card_listpre;
	pea_Card_ListScript pea_card_listscript;
	pea_Card_InitPRE pea_card_initpre;
	pea_Card_RunPRE pea_card_runpre;
	pea_Card_ExitPRE pea_card_exitpre;
	CString m_Output;
	card_obj_t ReaderObj;
private:
	CTabCtrl m_Tab;
public:
	afx_msg void OnBnClickedButtonEaConnect();
public:
	afx_msg void OnBnClickedButtonEaDisconnect();
public:
	afx_msg void OnBnClickedButtonEaAddScript();
public:
	afx_msg void OnBnClickedButtonAddPre();
public:
	afx_msg void OnBnClickedButtonEaListScript();
public:
	afx_msg void OnBnClickedButtonEaListPre();
public:
	afx_msg void OnBnClickedButtonEaDelScript();
public:
	afx_msg void OnBnClickedButtonEaDelPre();
public:
	afx_msg void OnBnClickedButtonEaInitPre();
public:
	afx_msg void OnBnClickedButtonEaRunPre();
public:
	afx_msg void OnBnClickedButtonEaExitPre();
public:
	afx_msg void OnBnClickedButtonEaLoadScript();
public:
	afx_msg void OnBnClickedButtonEaLoadPre();
public:
	virtual BOOL OnInitDialog();
};
