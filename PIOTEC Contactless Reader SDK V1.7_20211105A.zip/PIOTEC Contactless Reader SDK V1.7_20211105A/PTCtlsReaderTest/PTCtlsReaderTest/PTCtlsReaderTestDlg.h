// PTCtlsReaderTestDlg.h : ͷ�ļ�
//

#pragma once
#include "BaseDlg.h"
#include "AdvancedDlg.h"
#include "EmbeddedDlg.h"


// CPTCtlsReaderTestDlg �Ի���
class CPTCtlsReaderTestDlg : public CDialog
{
// ����
public:
	CPTCtlsReaderTestDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_PTCTLSREADERTEST_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
private:
	HINSTANCE m_hPTCtlsCardInstance;
	pCard_Open pcard_open;
	pCard_Close pcard_close;
	pCard_Reset pcard_reset;
	pCard_Apdu pcard_apdu;
	pCard_GetInfo pcard_getinfo;
	pCard_PPS pcard_pps;
	pCard_AutoModel pcard_automodel;
	pCard_SetModel pcard_setmodel;
	pCard_GetModel pcard_getmodel;

	pCard_On pcard_on;
	pCard_Off pcard_off;
	pCard_SetFreq pcard_setfreq;
	pCard_GetFreq pcard_getfreq;
	pCard_Reqa pcard_reqa;
	pCard_Wupa pcard_wupa;
	pCard_Anticol pcard_anticol;
	pCard_Select pcard_select;
	pCard_Halta pcard_halta;
	pCard_Rats pcard_rats;
	pCard_Reqb pcard_reqb;
	pCard_Wupb pcard_wupb;
	pCard_Attrib pcard_attrib;
	pCard_Haltb pcard_haltb;
	pCard_Deselect pcard_deselect;
	pCard_GetDetect pcard_getdetect;
	pCard_GetId pcard_getid;
	pCard_SetAttribInf pcard_setattribinf;
	pCard_GetAttribInf pcard_getattribinf;
	pCard_Authenticate pcard_authenticate;
	pCard_Mifare_Read pcard_mifare_read;
	pCard_Mifare_Write pcard_mifare_write;

	pea_Card_Connect pea_card_connect;
	pea_Card_Disconnect pea_card_disconnect;
	pea_Card_AddPRE pea_card_addpre;
	pea_Card_AddScript pea_card_addscript;
	pea_Card_DelPRE pea_card_delpre;
	pea_Card_DelScript pea_card_delscript;
	pea_Card_ListPRE pea_card_listpre;
	pea_Card_ListScript pea_card_listscript;
	pea_Card_InitPRE pea_card_initpre;
	pea_Card_RunPRE pea_card_runpre;
	pea_Card_ExitPRE pea_card_exitpre;
	CString m_Output;
public:
	int LoadPTCtlsReaderCtrlDll();
	afx_msg void OnBnClickedButtonClear();
public:
	CTabCtrl m_Tab;
	int m_CurSelTab;
	CBaseDlg m_BaseDlg;
	CAdvancedDlg m_AdvancedDlg;
	CEmbeddedDlg m_EmbeddedDlg;
	CDialog* pDialog[3];
public:
	afx_msg void OnTcnSelchangeModeTab(NMHDR *pNMHDR, LRESULT *pResult);
};
