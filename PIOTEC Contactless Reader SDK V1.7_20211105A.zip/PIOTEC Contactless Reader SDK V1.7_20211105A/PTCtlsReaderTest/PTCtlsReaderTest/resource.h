//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PTCtlsReaderTest.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_PTCTLSREADERTEST_DIALOG     102
#define IDR_MAINFRAME                   128
#define IDI_PIOTEC_ICON                 131
#define IDD_BASE_MODE_DIALOG            133
#define IDD_ADVANCED_MODE_DIALOG        134
#define IDD_EMBEDDED_DIALOG             136
#define IDC_MODE_TAB                    1000
#define IDC_EDIT_READER_INDEX           1001
#define IDC_BUTTON_REQA                 1001
#define IDC_BUTTON_OPEN                 1002
#define IDC_BUTTON_WUPA                 1002
#define IDC_BUTTON_CLOSE                1003
#define IDC_BUTTON_ANTICOL              1003
#define IDC_BUTTON_RESET                1004
#define IDC_BUTTON_SELECT               1004
#define IDC_BUTTON_RFON                 1005
#define IDC_BUTTON_RFOFF                1006
#define IDC_BUTTON_APDU                 1007
#define IDC_BUTTON_HALTA                1007
#define IDC_BUTTON_VERSION              1008
#define IDC_EDIT_SELECT_UID             1008
#define IDC_BUTTON_RATS                 1009
#define IDC_BUTTON_DESELECT             1010
#define IDC_BUTTON_DETECT               1011
#define IDC_EDIT_OUTPUT                 1012
#define IDC_RADIO_M_KEYA                1012
#define IDC_BUTTON_CLEAR                1013
#define IDC_RADIO_M_KEYB                1013
#define IDC_BUTTON_CLEAR2               1014
#define IDC_EDIT_M_BLOCK_NO             1014
#define IDC_EDIT_INPUT                  1015
#define IDC_EDIT_M_KEY1                 1015
#define IDC_EDIT_M_UID                  1016
#define IDC_BUTTON_M_AUTH               1017
#define IDC_BUTTON_REQB                 1018
#define IDC_BUTTON_PPS                  1019
#define IDC_BUTTON_WUPB                 1019
#define IDC_COMBO_DRI                   1020
#define IDC_BUTTON_ATTRIB               1020
#define IDC_COMBO_DSI                   1021
#define IDC_BUTTON_HALTB                1021
#define IDC_BUTTON_DESELECT2            1022
#define IDC_BUTTON_DETECT2              1023
#define IDC_EDIT_ATTRIB_INF             1024
#define IDC_BUTTON_GET_ATTRIB_INF       1025
#define IDC_EDIT_M_KEY2                 1026
#define IDC_EDIT_M_KEY3                 1027
#define IDC_EDIT_M_KEY4                 1028
#define IDC_EDIT_M_KEY5                 1029
#define IDC_EDIT_M_KEY6                 1030
#define IDC_BUTTON_SET_ATTRIB_INF       1031
#define IDC_BUTTON_GET_ID               1032
#define IDC_COMBO_PROTOCOL              1033
#define IDC_EDIT_M_UID2                 1033
#define IDC_EDIT_M_WRITE                1033
#define IDC_BUTTON_SET_PROTOCOL         1034
#define IDC_BUTTON_GET_PROTOCOL         1035
#define IDC_BUTTON_AUTO_PROTOCOL        1036
#define IDC_Edit                        1037
#define IDC_SPIN1                       1038
#define IDC_BUTTON_M_READ               1039
#define IDC_BUTTON_M_WRITE              1040
#define IDC_BUTTON_EA_CONNECT           1136
#define IDC_TAB_MODULE                  1138
#define IDC_TAB_MODE                    1138
#define IDC_BUTTON_EA_DISCONNECT        1139
#define IDC_EDIT_EA_SCRIPT_PATH         1140
#define IDC_EDIT_EA_PRE_PATH            1141
#define IDC_BUTTON_EA_ADD_SCRIPT        1142
#define IDC_BUTTON_EA_ADD_PRE           1143
#define IDC_BUTTON_EA_DEL_SCRIPT        1144
#define IDC_BUTTON_EA_DEL_PRE           1145
#define IDC_BUTTON_EA_LIST_SCRIPT       1146
#define IDC_BUTTON_EA_LIST_PRE          1147
#define IDC_BUTTON_EA_INIT_PRE          1148
#define IDC_BUTTON_EA_RUN_PRE           1149
#define IDC_BUTTON_EA_EXIT_PRE          1150
#define IDC_BUTTON_EA_LOAD_SCRIPT       1151
#define IDC_BUTTON_EA_LOAD_PRE          1152
#define IDC_EDIT_EA_SCRIPT_NAME         1154
#define IDC_EDIT_EA_PRE_NAME            1155
#define IDC_EDIT_EA_INIT_PRE_INPUT      1156
#define IDC_EDIT_EA_RUN_PRE_INPUT       1157
#define IDC_CHECK_EA_ADD_SCRIPT_FORCE   1158
#define IDC_CHECK_EA_ADD_PRE_FORCE      1159
#define IDC_COMBO_EA_SCRIPT_NAME        1161
#define IDC_COMBO2                      1162
#define IDC_COMBO_EA_PRE_NAME           1162
#define IDC_READER_IP                   1163
#define IDC_IPADDRESS1                  1164

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1041
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
